import json
import unittest
from pathlib import Path

from core.planner import PlanningError, build_plan, validate_task

ROOT = Path(__file__).resolve().parents[1]


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


class PlannerTests(unittest.TestCase):
    def setUp(self):
        self.task = load_json(ROOT / "config" / "task.example.json")
        self.registry = load_json(ROOT / "config" / "processor_registry.json")

    def test_sample_route_is_complete_but_not_executed(self):
        plan = build_plan(self.task, self.registry)
        self.assertEqual(plan["plan_status"], "COMPLETE")
        self.assertEqual(plan["plan_mode"], "PLAN_ONLY")
        self.assertEqual(plan["execution_status"], "NOT_INVOKED")
        self.assertFalse(plan["execution_invoked"])
        self.assertEqual(plan["unmet_capabilities"], [])
        self.assertEqual(plan["unmet_output_types"], [])
        self.assertEqual(len(plan["steps"]), 5)

    def test_missing_capability_returns_partial_plan(self):
        task = dict(self.task)
        task["required_capabilities"] = ["intent_normalization", "not_registered"]
        plan = build_plan(task, self.registry)
        self.assertEqual(plan["plan_status"], "PARTIAL")
        self.assertEqual(plan["unmet_capabilities"][0]["reason"], "NO_PROVIDER")

    def test_forbidden_mode_is_not_selected(self):
        task = dict(self.task)
        task["required_capabilities"] = ["reasoning"]
        task["constraints"] = {"forbidden_execution_modes": ["llm_adapter"]}
        plan = build_plan(task, self.registry)
        self.assertEqual(plan["plan_status"], "PARTIAL")
        self.assertEqual(plan["unmet_capabilities"][0]["reason"], "EXECUTION_MODE_FORBIDDEN")

    def test_input_type_mismatch_is_reported(self):
        task = dict(self.task)
        task["input_types"] = ["image"]
        task["required_capabilities"] = ["intent_normalization"]
        task["output_contract"] = []
        plan = build_plan(task, self.registry)
        self.assertEqual(plan["plan_status"], "PARTIAL")
        self.assertEqual(plan["unmet_capabilities"][0]["reason"], "INPUT_TYPE_MISMATCH")

    def test_verification_constraint_is_explicit(self):
        task = dict(self.task)
        task["required_capabilities"] = ["intent_normalization"]
        task["output_contract"] = []
        plan = build_plan(task, self.registry)
        self.assertIn("検証が必須", " ".join(plan["constraint_violations"]))
        self.assertEqual(plan["plan_status"], "PARTIAL")

    def test_bad_task_is_rejected(self):
        with self.assertRaises(PlanningError):
            validate_task({"task_id": "TASK-1", "goal": "x", "input_types": ["text"], "required_capabilities": []})

    def test_lower_priority_candidate_can_complete_downstream_route(self):
        task = {
            "task_id": "TASK-BACKTRACK",
            "goal": "select an end-to-end compatible route",
            "input_types": ["text"],
            "required_capabilities": ["parse", "reasoning", "verification"],
            "output_contract": ["verified"],
            "constraints": {}
        }
        registry = {"processors": [
            {"id": "PROC-001", "name": "Parser", "capabilities": ["parse"], "accepts": ["text"], "produces": ["task_spec"], "priority": 100, "status": "planning_only"},
            {"id": "PROC-002", "name": "High Priority Dead End", "capabilities": ["reasoning"], "accepts": ["task_spec"], "produces": ["bad_result"], "priority": 100, "status": "planning_only"},
            {"id": "PROC-003", "name": "Compatible Reasoner", "capabilities": ["reasoning"], "accepts": ["task_spec"], "produces": ["candidate"], "priority": 50, "status": "planning_only"},
            {"id": "PROC-004", "name": "Verifier", "capabilities": ["verification"], "accepts": ["candidate"], "produces": ["verified"], "priority": 90, "status": "planning_only"}
        ]}
        plan = build_plan(task, registry)
        self.assertEqual(plan["plan_status"], "COMPLETE")
        self.assertEqual(plan["steps"][1]["processor_id"], "PROC-003")
        self.assertEqual(plan["unmet_output_types"], [])

    def test_malformed_risk_level_and_context_refs_are_rejected(self):
        task = dict(self.task)
        task["risk_level"] = ["critical"]
        with self.assertRaises(PlanningError):
            build_plan(task, self.registry)
        task = dict(self.task)
        task["context_refs"] = "not-an-array"
        with self.assertRaises(PlanningError):
            build_plan(task, self.registry)

    def test_choice_is_deterministic(self):
        task = {
            "task_id": "TASK-DET",
            "goal": "deterministic selection",
            "input_types": ["text"],
            "required_capabilities": ["parse"],
            "output_contract": ["parsed"],
            "constraints": {}
        }
        registry = {"processors": [
            {"id": "PROC-010", "name": "Lower", "capabilities": ["parse"], "accepts": ["text"], "produces": ["parsed"], "priority": 10, "status": "planning_only"},
            {"id": "PROC-009", "name": "Higher tie-break", "capabilities": ["parse"], "accepts": ["text"], "produces": ["parsed"], "priority": 10, "status": "planning_only"}
        ]}
        plan = build_plan(task, registry)
        self.assertEqual(plan["steps"][0]["processor_id"], "PROC-009")


if __name__ == "__main__":
    unittest.main()
