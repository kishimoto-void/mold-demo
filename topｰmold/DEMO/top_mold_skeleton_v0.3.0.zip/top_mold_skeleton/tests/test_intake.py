import json
from pathlib import Path
import unittest

from core.intake import IntakeError, task_from_intake, validate_intake_packet

ROOT = Path(__file__).resolve().parents[1]


class IntakeContractTests(unittest.TestCase):
    def setUp(self):
        self.packet = json.loads((ROOT / "config" / "intake.example.json").read_text(encoding="utf-8"))

    def test_sample_packet_validates_and_maps_to_task(self):
        normalized = validate_intake_packet(self.packet)
        task = task_from_intake(self.packet)
        self.assertEqual(normalized["decision"]["status"], "READY")
        self.assertEqual(task["task_id"], "TASK-EXAMPLE-001")
        self.assertEqual(task["goal"], normalized["normalized_goal"])
        self.assertIn("verification", task["required_capabilities"])

    def test_ready_cannot_hide_blocking_question(self):
        packet = dict(self.packet)
        packet["open_questions"] = [{"question": "対象環境は何か", "blocking": True, "reason": "結果を左右する"}]
        with self.assertRaises(IntakeError):
            validate_intake_packet(packet)

    def test_clarification_requires_blocking_question(self):
        packet = dict(self.packet)
        packet["decision"] = {"status": "CLARIFICATION_REQUIRED", "rationale": "重要条件が未確定"}
        with self.assertRaises(IntakeError):
            validate_intake_packet(packet)

    def test_non_ready_packet_cannot_be_planned(self):
        packet = dict(self.packet)
        packet["open_questions"] = [{"question": "対象環境は何か", "blocking": True, "reason": "計画に必須"}]
        packet["decision"] = {"status": "CLARIFICATION_REQUIRED", "rationale": "対象環境が不明"}
        with self.assertRaises(IntakeError):
            task_from_intake(packet)

    def test_duplicate_atomic_requirement_id_rejected(self):
        packet = dict(self.packet)
        packet["atomic_requirements"] = self.packet["atomic_requirements"] + [self.packet["atomic_requirements"][0]]
        with self.assertRaises(IntakeError):
            validate_intake_packet(packet)


if __name__ == "__main__":
    unittest.main()
