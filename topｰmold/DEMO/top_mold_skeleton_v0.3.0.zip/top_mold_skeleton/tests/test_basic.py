import json
import tempfile
import unittest
from pathlib import Path

from core.personalization import (
    complexity_advice,
    load_dial_catalog,
    load_settings,
    update_dial,
    build_dial_overlay,
    build_personalization_overlay,
    select_visible_dials,
    DialConfigError,
)
from core.registry import load_mold_registry
from core.startup import inspect_persona_file

ROOT = Path(__file__).resolve().parents[1]


class StartupTests(unittest.TestCase):
    def test_absent_md(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            result = inspect_persona_file(Path(temp_dir) / "missing.md")
            self.assertEqual(result.status, "ABSENT")

    def test_present_md(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "persona.md"
            path.write_text("# Persona\nhello\n", encoding="utf-8")
            result = inspect_persona_file(path)
            self.assertEqual(result.status, "PRESENT")
            self.assertIn("hello", result.content or "")

    def test_empty_md(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "persona.md"
            path.write_text("  \n", encoding="utf-8")
            self.assertEqual(inspect_persona_file(path).status, "EMPTY")


class PersonalizationTests(unittest.TestCase):
    def setUp(self):
        self.catalog = load_dial_catalog(ROOT / "config" / "dials.json")

    def test_default_has_eight_initial_dials(self):
        settings = load_settings(ROOT / "nonexistent-settings.json", self.catalog)
        self.assertEqual(len(settings["active_dial_ids"]), 8)
        self.assertIsNone(complexity_advice(settings, threshold=10))

    def test_advanced_dials_are_hidden_until_requested_or_activated(self):
        settings = load_settings(ROOT / "nonexistent-settings.json", self.catalog)
        self.assertEqual(len(select_visible_dials(self.catalog, settings)), 8)
        self.assertEqual(len(select_visible_dials(self.catalog, settings, include_advanced=True)), 13)
        settings = update_dial(settings, self.catalog, "D-009", 3)
        self.assertEqual(len(select_visible_dials(self.catalog, settings)), 9)

    def test_threshold_proposes_at_ten(self):
        settings = load_settings(ROOT / "nonexistent-settings.json", self.catalog)
        settings = update_dial(settings, self.catalog, "D-009", 3)
        settings = update_dial(settings, self.catalog, "D-010", 3)
        advice = complexity_advice(settings, threshold=10)
        self.assertIsNotNone(advice)
        self.assertIn("自動変更しません", advice or "")

    def test_overlay_compiles_dials_and_preserves_hard_invariants(self):
        settings = load_settings(ROOT / "nonexistent-settings.json", self.catalog)
        settings = update_dial(settings, self.catalog, "D-003", 5)
        settings = update_dial(settings, self.catalog, "D-013", 5)
        overlay = build_dial_overlay(settings, self.catalog)
        directives = {item["dial_id"]: item["directive"] for item in overlay["preferences"]}
        self.assertIn("comprehensive validation", directives["D-003"])
        self.assertIn("retry budget", directives["D-013"])
        self.assertTrue(overlay["non_overridable_invariants"])

    def test_persona_seed_and_dials_are_compiled_as_separate_layers(self):
        settings = load_settings(ROOT / "nonexistent-settings.json", self.catalog)
        seed = json.loads((ROOT / "config" / "persona_seed.example.json").read_text(encoding="utf-8"))
        overlay = build_personalization_overlay(settings, self.catalog, seed)
        self.assertEqual(overlay["overlay_type"], "personalization")
        self.assertEqual(overlay["persona_seed"]["seed_id"], seed["seed_id"])
        self.assertEqual(len(overlay["dials"]), 8)
        self.assertTrue(overlay["non_overridable_invariants"])

    def test_invalid_persona_seed_schema_is_rejected(self):
        settings = load_settings(ROOT / "nonexistent-settings.json", self.catalog)
        with self.assertRaises(DialConfigError):
            build_personalization_overlay(settings, self.catalog, {"schema": "wrong"})

    def test_invalid_overlay_value_is_rejected(self):
        settings = load_settings(ROOT / "nonexistent-settings.json", self.catalog)
        settings["values"]["D-001"] = True
        with self.assertRaises(DialConfigError):
            build_dial_overlay(settings, self.catalog)

    def test_dial_range_is_validated(self):
        settings = load_settings(ROOT / "nonexistent-settings.json", self.catalog)
        with self.assertRaises(DialConfigError):
            update_dial(settings, self.catalog, "D-001", 6)

    def test_malformed_settings_shape_is_rejected(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "settings.json"
            path.write_text("[]", encoding="utf-8")
            with self.assertRaises(DialConfigError):
                load_settings(path, self.catalog)

    def test_unknown_dial_in_persisted_settings_is_not_discarded_silently(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "settings.json"
            path.write_text(json.dumps({"active_dial_ids": ["D-999"], "values": {"D-999": 3}}), encoding="utf-8")
            with self.assertRaises(DialConfigError):
                load_settings(path, self.catalog)

    def test_boolean_is_not_a_valid_dial_integer(self):
        settings = load_settings(ROOT / "nonexistent-settings.json", self.catalog)
        with self.assertRaises(DialConfigError):
            update_dial(settings, self.catalog, "D-001", True)

    def test_unknown_dial_is_rejected(self):
        settings = load_settings(ROOT / "nonexistent-settings.json", self.catalog)
        with self.assertRaises(DialConfigError):
            update_dial(settings, self.catalog, "D-999", 3)


class RegistryTests(unittest.TestCase):
    def test_registry_loads_without_duplicate_ids(self):
        molds = load_mold_registry(ROOT / "config" / "mold_registry.json")
        self.assertEqual(len(molds), 15)
        ids = [item["id"] for item in molds]
        self.assertEqual(len(ids), len(set(ids)))


if __name__ == "__main__":
    unittest.main()
