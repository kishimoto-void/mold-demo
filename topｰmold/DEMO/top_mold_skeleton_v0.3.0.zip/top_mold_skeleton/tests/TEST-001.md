# TEST-001 — Basic Conformance

## Target
- Mold ID registry
- Startup MD state detection
- Personalization dial range validation
- 10-dial complexity suggestion threshold

## Run

```bash
python -m unittest discover -s tests -v
```

## Expected result
- 既定の初期ダイヤル数は 8 個。
- `D-009` と `D-010` を追加して 10 個になった場合、整理の提案が返る。
- 不正な値や未登録ダイヤルは拒否される。
- モールド ID の重複がない。

## Execution environment
- テスト作成時の環境：Python 3.10 以上を想定
- 実行端末：実際にテストを実行した環境を記録する。
