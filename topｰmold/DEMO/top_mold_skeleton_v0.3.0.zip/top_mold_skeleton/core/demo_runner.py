"""Small deterministic demonstrations of the skeleton's intended branches."""
import json
from pathlib import Path
from .personalization import complexity_advice, load_dial_catalog, load_settings, update_dial
from .startup import inspect_persona_file
from .planner import build_plan


def run_demo(demo_id: str, root: Path) -> str:
    root = Path(root)
    dial_catalog = load_dial_catalog(root / "config" / "dials.json")
    lines: list[str] = [f"{demo_id} — デモ（設計骨格）"]

    if demo_id == "DEMO-001":
        state = inspect_persona_file(root / "not-present-persona.md")
        lines.extend([
            "Step 1: 起動時に MD の有無を確認",
            f"Step 2: 状態 = {state.status} — {state.message}",
            "Step 3: 案内付き設定または標準設定を利用者に提示",
            "期待結果: MD がないことを異常終了扱いにせず、初期案内へ進む",
        ])
    elif demo_id == "DEMO-002":
        state = inspect_persona_file(root / "config" / "persona.example.md")
        lines.extend([
            "Step 1: 既存 MD を読み込む",
            f"Step 2: 状態 = {state.status} — {state.message}",
            "Step 3: 既存内容を維持し、内容の上書きは行わない",
            "期待結果: 読み込み可能な MD を既存設定として識別する",
        ])
    elif demo_id == "DEMO-003":
        settings = load_settings(root / "runtime" / "demo-settings.json", dial_catalog)
        before = settings["values"].get("D-001", 3)
        settings = update_dial(settings, dial_catalog, "D-001", 4)
        lines.extend([
            "Step 1: 現在の設定を保持する",
            f"Step 2: 利用者の明示的な要求を想定し D-001 を {before} から 4 に更新",
            f"Step 3: 更新後の D-001 = {settings['values']['D-001']}",
            "期待結果: 対象ダイヤルだけを更新し、他の値を保持する",
        ])
    elif demo_id == "DEMO-004":
        settings = load_settings(root / "runtime" / "demo-settings.json", dial_catalog)
        for dial_id in ("D-009", "D-010"):
            settings = update_dial(settings, dial_catalog, dial_id, 3)
        advice = complexity_advice(settings, threshold=10)
        lines.extend([
            f"Step 1: 有効なダイヤル数 = {len(settings['active_dial_ids'])}",
            "Step 2: 閾値 10 個以上かを判定",
            f"Step 3: 提案 = {'あり' if advice else 'なし'}",
            advice or "現在は拡張提案の閾値未満です。",
            "期待結果: 閾値に達した場合でも、設定を勝手に統合・削除しない",
        ])
    elif demo_id == "DEMO-005":
        task = json.loads((root / "config" / "task.example.json").read_text(encoding="utf-8"))
        registry = json.loads((root / "config" / "processor_registry.json").read_text(encoding="utf-8"))
        plan = build_plan(task, registry)
        lines.extend([
            "Step 1: タスク契約から必要能力の順序を取得",
            f"Step 2: 計画状態 = {plan['plan_status']} / 実行準備 = {plan['plan_mode']}",
            "Step 3: 能力・入力型・実行制約を照合してルートを選択",
            "選択された経路:",
            *[f"  {item['step_id']} {item['processor_id']} — {item['primary_capability']} → {', '.join(item['produces']) or '(出力型未宣言)'}" for item in plan['steps']],
            f"未充足能力: {len(plan['unmet_capabilities'])}",
            "実行状態: NOT_INVOKED（このデモは計画生成のみ。LLMや外部処理は呼び出さない）",
            "期待結果: 同じ入力・同じレジストリから決定的な計画が生成される",
        ])
    else:
        return f"未登録のデモ ID です: {demo_id}"

    return "\n".join(lines)
