"""Read and validate the static mold registry."""
import json
from pathlib import Path
from typing import Any


class RegistryError(ValueError):
    """Raised when the registry has duplicate or malformed IDs."""


def load_mold_registry(path: Path) -> list[dict[str, Any]]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    molds = data.get("molds", [])
    seen: set[str] = set()
    for item in molds:
        mold_id = item.get("id")
        if not isinstance(mold_id, str) or not mold_id.startswith("MOLD-"):
            raise RegistryError(f"不正なモールド ID: {mold_id!r}")
        if mold_id in seen:
            raise RegistryError(f"モールド ID が重複しています: {mold_id}")
        seen.add(mold_id)
    return molds


def find_mold(molds: list[dict[str, Any]], mold_id: str) -> dict[str, Any] | None:
    return next((item for item in molds if item.get("id") == mold_id), None)
