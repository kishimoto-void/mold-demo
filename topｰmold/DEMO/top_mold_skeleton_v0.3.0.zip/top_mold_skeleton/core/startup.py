"""Startup state inspection for a persona Markdown file."""
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


@dataclass(frozen=True)
class PersonaFileState:
    status: str
    path: str
    message: str
    content: Optional[str] = None


def inspect_persona_file(path: Path) -> PersonaFileState:
    """Return ABSENT, PRESENT, EMPTY, or ERROR without modifying the file."""
    path = Path(path)
    if not path.exists():
        return PersonaFileState(
            status="ABSENT",
            path=str(path),
            message="パーソナライズ用 MD が見つかりません。",
        )
    if not path.is_file():
        return PersonaFileState(
            status="ERROR",
            path=str(path),
            message="指定先はファイルではありません。",
        )
    try:
        content = path.read_text(encoding="utf-8")
    except (OSError, UnicodeError) as exc:
        return PersonaFileState(
            status="ERROR",
            path=str(path),
            message=f"MD を読み込めませんでした: {exc}",
        )
    if not content.strip():
        return PersonaFileState(
            status="EMPTY",
            path=str(path),
            message="MD は存在しますが、内容が空です。",
            content=content,
        )
    return PersonaFileState(
        status="PRESENT",
        path=str(path),
        message="パーソナライズ用 MD を読み込みました。",
        content=content,
    )
