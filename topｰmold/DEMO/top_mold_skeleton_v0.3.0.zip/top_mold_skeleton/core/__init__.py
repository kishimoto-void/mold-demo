"""Core modules for the provider-neutral Top Mold control skeleton."""
