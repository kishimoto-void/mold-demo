"""Provider-neutral, declarative capability-route planner.

This module creates a plan only. It never invokes an LLM, tool, or processor.
"""
from __future__ import annotations

from typing import Any


class PlanningError(ValueError):
    """Raised when a task or processor registry violates the planning contract."""


_VALID_PROCESSOR_STATUSES = {"planning_only", "ready", "disabled"}


def _string_list(value: Any, field: str, *, allow_empty: bool = True) -> list[str]:
    if not isinstance(value, list) or any(not isinstance(item, str) or not item.strip() for item in value):
        raise PlanningError(f"{field} は空でない文字列からなる配列で指定してください。")
    result = [item.strip() for item in value]
    if not allow_empty and not result:
        raise PlanningError(f"{field} は1件以上必要です。")
    if len(result) != len(set(result)):
        raise PlanningError(f"{field} に重複があります。")
    return result


def validate_task(task: dict[str, Any]) -> dict[str, Any]:
    """Validate and normalize a task envelope without mutating the caller's object."""
    if not isinstance(task, dict):
        raise PlanningError("タスク定義は JSON オブジェクトである必要があります。")

    task_id = task.get("task_id")
    goal = task.get("goal")
    if not isinstance(task_id, str) or not task_id.strip():
        raise PlanningError("task_id が必要です。")
    if not isinstance(goal, str) or not goal.strip():
        raise PlanningError("goal が必要です。")

    input_types = _string_list(task.get("input_types", []), "input_types", allow_empty=False)
    required = _string_list(
        task.get("required_capabilities", []),
        "required_capabilities",
        allow_empty=False,
    )
    output_contract = _string_list(task.get("output_contract", []), "output_contract")
    constraints = task.get("constraints", {})
    if not isinstance(constraints, dict):
        raise PlanningError("constraints は JSON オブジェクトで指定してください。")

    forbidden_modes = _string_list(
        constraints.get("forbidden_execution_modes", []),
        "constraints.forbidden_execution_modes",
    )
    for flag in ("require_verification", "human_approval_required"):
        if flag in constraints and not isinstance(constraints[flag], bool):
            raise PlanningError(f"constraints.{flag} は true / false で指定してください。")

    risk_level = task.get("risk_level", "normal")
    if not isinstance(risk_level, str) or risk_level not in {"low", "normal", "high", "critical"}:
        raise PlanningError("risk_level は low / normal / high / critical のいずれかです。")
    context_refs = _string_list(task.get("context_refs", []), "context_refs")

    return {
        "schema_version": str(task.get("schema_version", "0.3")),
        "task_id": task_id.strip(),
        "goal": goal.strip(),
        "input_types": input_types,
        "required_capabilities": required,
        "output_contract": output_contract,
        "constraints": {
            **constraints,
            "forbidden_execution_modes": forbidden_modes,
            "require_verification": constraints.get("require_verification", False),
            "human_approval_required": constraints.get("human_approval_required", False),
        },
        "risk_level": risk_level,
        "context_refs": context_refs,
    }


def validate_processor_registry(registry: dict[str, Any]) -> list[dict[str, Any]]:
    """Validate processor descriptors and return a normalized copy."""
    if not isinstance(registry, dict) or not isinstance(registry.get("processors"), list):
        raise PlanningError("プロセッサレジストリに processors 配列が必要です。")

    processors: list[dict[str, Any]] = []
    seen: set[str] = set()
    for index, raw in enumerate(registry["processors"]):
        if not isinstance(raw, dict):
            raise PlanningError(f"processors[{index}] は JSON オブジェクトである必要があります。")
        processor_id = raw.get("id")
        name = raw.get("name")
        if not isinstance(processor_id, str) or not processor_id.startswith("PROC-"):
            raise PlanningError(f"不正なプロセッサ ID: {processor_id!r}")
        if processor_id in seen:
            raise PlanningError(f"プロセッサ ID が重複しています: {processor_id}")
        seen.add(processor_id)
        if not isinstance(name, str) or not name.strip():
            raise PlanningError(f"{processor_id}: name が必要です。")

        capabilities = _string_list(raw.get("capabilities", []), f"{processor_id}.capabilities", allow_empty=False)
        accepts = _string_list(raw.get("accepts", []), f"{processor_id}.accepts")
        produces = _string_list(raw.get("produces", []), f"{processor_id}.produces")
        status = raw.get("status", "planning_only")
        if not isinstance(status, str) or status not in _VALID_PROCESSOR_STATUSES:
            raise PlanningError(f"{processor_id}: status が不正です: {status!r}")
        version = raw.get("version", "0.0.0")
        if not isinstance(version, str) or not version.strip():
            raise PlanningError(f"{processor_id}: version は空でない文字列で指定してください。")
        execution_mode = raw.get("execution_mode", "unspecified")
        if not isinstance(execution_mode, str) or not execution_mode.strip():
            raise PlanningError(f"{processor_id}: execution_mode が必要です。")
        priority = raw.get("priority", 0)
        if not isinstance(priority, int) or isinstance(priority, bool):
            raise PlanningError(f"{processor_id}: priority は整数で指定してください。")
        adapter_id = raw.get("adapter_id")
        if adapter_id is not None and (not isinstance(adapter_id, str) or not adapter_id.strip()):
            raise PlanningError(f"{processor_id}: adapter_id は文字列または null です。")
        entrypoint = raw.get("entrypoint")
        if entrypoint is not None and (not isinstance(entrypoint, str) or not entrypoint.strip()):
            raise PlanningError(f"{processor_id}: entrypoint は文字列または null です。")

        processors.append({
            **raw,
            "id": processor_id,
            "name": name.strip(),
            "version": version.strip(),
            "capabilities": capabilities,
            "accepts": accepts,
            "produces": produces,
            "status": status,
            "execution_mode": execution_mode.strip(),
            "priority": priority,
            "adapter_id": adapter_id,
            "entrypoint": entrypoint,
        })

    return processors


def build_plan(task: dict[str, Any], registry: dict[str, Any]) -> dict[str, Any]:
    """Build a deterministic, end-to-end compatible route from an explicit sequence.

    Candidate paths are explored in priority order. A lower-priority candidate can
    win when it is the one that allows downstream capabilities / output contracts
    to connect. This function only plans; it never invokes a processor.
    """
    normalized_task = validate_task(task)
    processors = validate_processor_registry(registry)
    constraints = normalized_task["constraints"]
    forbidden_modes = set(constraints["forbidden_execution_modes"])
    initial_types = set(normalized_task["input_types"])
    required = normalized_task["required_capabilities"]
    output_contract = normalized_task["output_contract"]

    def candidates_for(capability: str, available_types: set[str]) -> tuple[list[dict[str, Any]], str | None, dict[str, Any] | None]:
        providers = [
            item for item in processors
            if item["status"] != "disabled" and capability in item["capabilities"]
        ]
        if not providers:
            return [], "NO_PROVIDER", {"capability": capability, "reason": "NO_PROVIDER", "detail": "レジストリに対応プロセッサがありません。"}
        allowed = [item for item in providers if item["execution_mode"] not in forbidden_modes]
        if not allowed:
            return [], "EXECUTION_MODE_FORBIDDEN", {"capability": capability, "reason": "EXECUTION_MODE_FORBIDDEN", "detail": "候補の実行モードがタスク制約で禁止されています。"}
        compatible = [
            item for item in allowed
            if not item["accepts"] or bool(set(item["accepts"]) & available_types)
        ]
        if not compatible:
            expected_inputs = sorted({t for item in allowed for t in item["accepts"]})
            return [], "INPUT_TYPE_MISMATCH", {
                "capability": capability,
                "reason": "INPUT_TYPE_MISMATCH",
                "detail": "現在のデータ型と候補の受入型が接続できません。",
                "available_types": sorted(available_types),
                "candidate_accepts": expected_inputs,
            }
        compatible.sort(key=lambda item: (-item["priority"], item["id"]))
        return compatible, None, None

    best: dict[str, Any] | None = None
    visited_states = 0
    max_states = 50000

    def explore(
        index: int,
        available_types: set[str],
        steps: list[dict[str, Any]],
        coverage: dict[str, dict[str, Any]],
        priority_by_capability: dict[str, int],
        skipped: list[dict[str, Any]],
    ) -> None:
        nonlocal best, visited_states
        visited_states += 1
        if visited_states > max_states:
            return

        if index >= len(required):
            unmet_outputs = [out for out in output_contract if out not in available_types]
            verification_covered = "verification" in coverage
            constraint_violations: list[str] = []
            if constraints["require_verification"] and not verification_covered:
                constraint_violations.append(
                    "タスク制約で検証が必須ですが、指定された能力順序に検証能力が含まれていません。"
                )
            route_complete = not skipped and not unmet_outputs and not constraint_violations
            priority_vector = tuple(priority_by_capability.get(cap, -10**9) for cap in required)
            score = (
                int(route_complete),
                len(coverage),
                int(verification_covered or not constraints["require_verification"]),
                len(output_contract) - len(unmet_outputs),
                priority_vector,
                -len(steps),
            )
            candidate = {
                "steps": steps,
                "coverage": coverage,
                "skipped": skipped,
                "available_types": available_types,
                "unmet_output_types": unmet_outputs,
                "constraint_violations": constraint_violations,
                "route_complete": route_complete,
                "score": score,
            }
            if best is None or score > best["score"]:
                best = candidate
            return

        capability = required[index]
        if capability in coverage:
            explore(index + 1, available_types, steps, coverage, priority_by_capability, skipped)
            return

        candidates, failure_reason, failure_detail = candidates_for(capability, available_types)
        for chosen in candidates:
            covered_caps = [
                cap for cap in required[index:]
                if cap in chosen["capabilities"] and cap not in coverage
            ] or [capability]
            step_id = f"STEP-{len(steps) + 1:03d}"
            matched_inputs = sorted(set(chosen["accepts"]) & available_types) if chosen["accepts"] else sorted(available_types)
            step = {
                "step_id": step_id,
                "processor_id": chosen["id"],
                "processor_name": chosen["name"],
                "primary_capability": capability,
                "capabilities_fulfilled": covered_caps,
                "accepts": chosen["accepts"],
                "matched_input_types": matched_inputs,
                "produces": chosen["produces"],
                "execution_mode": chosen["execution_mode"],
                "processor_status": chosen["status"],
                "adapter_id": chosen.get("adapter_id"),
                "entrypoint": chosen["entrypoint"],
                "selection_reason": (
                    f"能力 '{capability}' を提供し、入力型が適合。優先度 {chosen['priority']}。"
                    "全体のルート適合性を確認し、同条件時は ID 昇順で選択。"
                ),
            }
            next_coverage = dict(coverage)
            next_priorities = dict(priority_by_capability)
            for covered_capability in covered_caps:
                next_coverage[covered_capability] = {
                    "status": "covered",
                    "step_id": step_id,
                    "processor_id": chosen["id"],
                    "provided_as": "declared_capability",
                }
                next_priorities[covered_capability] = chosen["priority"]
            explore(
                index + 1,
                available_types | set(chosen["produces"]),
                steps + [step],
                next_coverage,
                next_priorities,
                skipped,
            )

        # Always preserve a partial-plan branch. If a provider was compatible,
        # the end-to-end score will normally prefer a route that includes it.
        _, _, skip_reason = candidates_for(capability, available_types)
        explore(
            index + 1,
            available_types,
            steps,
            coverage,
            priority_by_capability,
            skipped + [skip_reason or {
                "capability": capability,
                "reason": "ROUTE_SELECTION_CONFLICT",
                "detail": "完全なルートを作れる候補がなく、この能力は未充足として残しました。",
            }],
        )

    explore(0, initial_types, [], {}, {}, [])
    if best is None:
        # The search ceiling is a defensive safeguard against a pathological
        # registry; do not claim a route was found in that case.
        raise PlanningError("ルート探索の上限に達しました。タスクまたは候補レジストリを小さくしてください。")

    unmet = best["skipped"]
    # Keep the first failure per capability only; preserve task order.
    unmet_by_capability = {item["capability"]: item for item in unmet}
    unmet = [unmet_by_capability[cap] for cap in required if cap in unmet_by_capability]
    route_complete = best["route_complete"]
    all_bound = all(
        step["processor_status"] == "ready" and step["entrypoint"]
        for step in best["steps"]
    )
    plan_mode = "READY_FOR_ADAPTER" if route_complete and all_bound else "PLAN_ONLY"
    approval_state = "REQUIRED" if constraints["human_approval_required"] else "NOT_REQUIRED_BY_TASK"
    warnings = [
        "この骨格は宣言的なルート計画のみを生成します。プロセッサ・LLM・外部ツールは実行していません。",
        "能力の順序は task.required_capabilities に記載された順序を使用し、トップモールド側で勝手に推測・並べ替えません。",
    ]
    if normalized_task["risk_level"] in {"high", "critical"} and not constraints["human_approval_required"]:
        warnings.append("リスク水準が high / critical です。必要な人間承認ルールをタスク制約に明示してください。")
    if best["constraint_violations"]:
        warnings.extend(best["constraint_violations"])
    if visited_states > max_states:
        warnings.append("探索上限に達したため、完全な最適化を保証できません。")

    return {
        "schema_version": "0.3",
        "task_id": normalized_task["task_id"],
        "goal": normalized_task["goal"],
        "plan_status": "COMPLETE" if route_complete else "PARTIAL",
        "plan_mode": plan_mode,
        "execution_status": "NOT_INVOKED",
        "execution_invoked": False,
        "approval_state": approval_state,
        "required_capabilities": required,
        "capability_coverage": [
            {"capability": capability, **best["coverage"][capability]}
            if capability in best["coverage"]
            else {"capability": capability, "status": "unmet"}
            for capability in required
        ],
        "steps": best["steps"],
        "unmet_capabilities": unmet,
        "unmet_output_types": best["unmet_output_types"],
        "constraint_violations": best["constraint_violations"],
        "available_types_at_end": sorted(best["available_types"]),
        "warnings": warnings,
    }
