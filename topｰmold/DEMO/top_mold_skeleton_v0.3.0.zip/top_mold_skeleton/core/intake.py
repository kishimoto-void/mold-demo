"""Request-intake contract validation for the provider-neutral Top Mold.

This module validates a structured packet emitted by a pluggable intent compiler
(LLM, local model, a human, or another mold). It does not interpret free text.
"""
from __future__ import annotations

from copy import deepcopy
from typing import Any

from .planner import PlanningError, validate_task


class IntakeError(ValueError):
    """Raised when a request-intake packet violates its contract."""


_DECISION_STATUSES = {"READY", "CLARIFICATION_REQUIRED", "BLOCKED"}
_PRIORITIES = {"must", "should", "could"}
_CONFIDENCE = {"low", "medium", "high"}
_IMPACT = {"low", "medium", "high"}


def _nonempty_string(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise IntakeError(f"{field} は空でない文字列で指定してください。")
    return value.strip()


def _string_list(value: Any, field: str, *, minimum: int = 0) -> list[str]:
    if not isinstance(value, list) or any(not isinstance(x, str) or not x.strip() for x in value):
        raise IntakeError(f"{field} は空でない文字列からなる配列で指定してください。")
    result = [x.strip() for x in value]
    if len(result) != len(set(result)):
        raise IntakeError(f"{field} に重複があります。")
    if len(result) < minimum:
        raise IntakeError(f"{field} は {minimum} 件以上必要です。")
    return result


def validate_intake_packet(packet: dict[str, Any]) -> dict[str, Any]:
    """Validate a structured intent packet and normalize its nested task contract.

    Semantic decomposition is performed upstream by a pluggable intent compiler.
    This function only validates explicit structure and cross-field consistency.
    """
    if not isinstance(packet, dict):
        raise IntakeError("intake packet は JSON オブジェクトである必要があります。")

    request_id = _nonempty_string(packet.get("request_id"), "request_id")
    raw_request = _nonempty_string(packet.get("raw_request"), "raw_request")
    normalized_goal = _nonempty_string(packet.get("normalized_goal"), "normalized_goal")

    raw_requirements = packet.get("atomic_requirements")
    if not isinstance(raw_requirements, list) or not raw_requirements:
        raise IntakeError("atomic_requirements は1件以上必要です。")
    requirements: list[dict[str, str]] = []
    seen_ids: set[str] = set()
    for index, item in enumerate(raw_requirements):
        field = f"atomic_requirements[{index}]"
        if not isinstance(item, dict):
            raise IntakeError(f"{field} は JSON オブジェクトである必要があります。")
        req_id = _nonempty_string(item.get("id"), f"{field}.id")
        if req_id in seen_ids:
            raise IntakeError(f"atomic requirement ID が重複しています: {req_id}")
        seen_ids.add(req_id)
        statement = _nonempty_string(item.get("statement"), f"{field}.statement")
        priority = item.get("priority", "must")
        if not isinstance(priority, str) or priority not in _PRIORITIES:
            raise IntakeError(f"{field}.priority は must / should / could のいずれかです。")
        origin = item.get("origin", "explicit")
        if not isinstance(origin, str) or origin not in {"explicit", "inferred"}:
            raise IntakeError(f"{field}.origin は explicit / inferred のいずれかです。")
        acceptance = item.get("acceptance_criterion", "")
        if not isinstance(acceptance, str):
            raise IntakeError(f"{field}.acceptance_criterion は文字列で指定してください。")
        requirements.append({
            "id": req_id,
            "statement": statement,
            "priority": priority,
            "origin": origin,
            "acceptance_criterion": acceptance.strip(),
        })

    raw_assumptions = packet.get("assumptions", [])
    if not isinstance(raw_assumptions, list):
        raise IntakeError("assumptions は配列で指定してください。")
    assumptions: list[dict[str, str]] = []
    for index, item in enumerate(raw_assumptions):
        field = f"assumptions[{index}]"
        if not isinstance(item, dict):
            raise IntakeError(f"{field} は JSON オブジェクトである必要があります。")
        statement = _nonempty_string(item.get("statement"), f"{field}.statement")
        confidence = item.get("confidence", "medium")
        impact = item.get("impact", "medium")
        if not isinstance(confidence, str) or confidence not in _CONFIDENCE:
            raise IntakeError(f"{field}.confidence は low / medium / high のいずれかです。")
        if not isinstance(impact, str) or impact not in _IMPACT:
            raise IntakeError(f"{field}.impact は low / medium / high のいずれかです。")
        assumptions.append({"statement": statement, "confidence": confidence, "impact": impact})

    raw_questions = packet.get("open_questions", [])
    if not isinstance(raw_questions, list):
        raise IntakeError("open_questions は配列で指定してください。")
    questions: list[dict[str, Any]] = []
    for index, item in enumerate(raw_questions):
        field = f"open_questions[{index}]"
        if not isinstance(item, dict):
            raise IntakeError(f"{field} は JSON オブジェクトである必要があります。")
        question = _nonempty_string(item.get("question"), f"{field}.question")
        blocking = item.get("blocking", False)
        if not isinstance(blocking, bool):
            raise IntakeError(f"{field}.blocking は true / false で指定してください。")
        reason = item.get("reason", "")
        if not isinstance(reason, str):
            raise IntakeError(f"{field}.reason は文字列で指定してください。")
        questions.append({"question": question, "blocking": blocking, "reason": reason.strip()})

    acceptance_criteria = _string_list(packet.get("acceptance_criteria", []), "acceptance_criteria", minimum=1)
    constraints = _string_list(packet.get("known_constraints", []), "known_constraints")
    routing = packet.get("routing")
    if not isinstance(routing, dict):
        raise IntakeError("routing は Task Envelope の項目を含む JSON オブジェクトである必要があります。")

    task_candidate = {
        "schema_version": str(packet.get("schema_version", "0.3")),
        "task_id": routing.get("task_id", request_id.replace("REQ-", "TASK-", 1)),
        "goal": normalized_goal,
        "input_types": routing.get("input_types", ["text"]),
        "required_capabilities": routing.get("required_capabilities", []),
        "output_contract": routing.get("output_contract", []),
        "constraints": routing.get("constraints", {}),
        "risk_level": routing.get("risk_level", "normal"),
        "context_refs": routing.get("context_refs", []),
    }
    try:
        normalized_task = validate_task(task_candidate)
    except PlanningError as exc:
        raise IntakeError(f"routing の Task Envelope が不正です: {exc}") from exc

    decision = packet.get("decision")
    if not isinstance(decision, dict):
        raise IntakeError("decision オブジェクトが必要です。")
    status = decision.get("status")
    if not isinstance(status, str) or status not in _DECISION_STATUSES:
        raise IntakeError("decision.status は READY / CLARIFICATION_REQUIRED / BLOCKED のいずれかです。")
    rationale = _nonempty_string(decision.get("rationale"), "decision.rationale")
    blocking_questions = [q for q in questions if q["blocking"]]
    if status == "READY" and blocking_questions:
        raise IntakeError("READY と blocking=true の未解決質問は両立しません。")
    if status == "CLARIFICATION_REQUIRED" and not blocking_questions:
        raise IntakeError("CLARIFICATION_REQUIRED には blocking=true の質問が必要です。")
    if status == "BLOCKED" and not rationale:
        raise IntakeError("BLOCKED の場合、decision.rationale に停止理由が必要です。")

    result = deepcopy(packet)
    result.update({
        "schema_version": str(packet.get("schema_version", "0.3")),
        "request_id": request_id,
        "raw_request": raw_request,
        "normalized_goal": normalized_goal,
        "atomic_requirements": requirements,
        "assumptions": assumptions,
        "open_questions": questions,
        "acceptance_criteria": acceptance_criteria,
        "known_constraints": constraints,
        "routing": {
            "task_id": normalized_task["task_id"],
            "input_types": normalized_task["input_types"],
            "required_capabilities": normalized_task["required_capabilities"],
            "output_contract": normalized_task["output_contract"],
            "constraints": normalized_task["constraints"],
            "risk_level": normalized_task["risk_level"],
            "context_refs": normalized_task["context_refs"],
        },
        "decision": {"status": status, "rationale": rationale},
    })
    return result


def task_from_intake(packet: dict[str, Any]) -> dict[str, Any]:
    """Return the normalized Task Envelope if and only if intake is READY."""
    validated = validate_intake_packet(packet)
    status = validated["decision"]["status"]
    if status != "READY":
        raise IntakeError(f"Task Envelope を生成できません。intake decision={status}")
    routing = validated["routing"]
    return {
        "schema_version": validated["schema_version"],
        "task_id": routing["task_id"],
        "goal": validated["normalized_goal"],
        "input_types": routing["input_types"],
        "required_capabilities": routing["required_capabilities"],
        "output_contract": routing["output_contract"],
        "constraints": routing["constraints"],
        "risk_level": routing["risk_level"],
        "context_refs": routing["context_refs"],
    }
