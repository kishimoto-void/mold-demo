"""Persona/Dial configuration, neutral overlays, and complexity guidance."""
import json
from pathlib import Path
from typing import Any


class DialConfigError(ValueError):
    """Raised when a dial or dial value is invalid."""


def load_dial_catalog(path: Path) -> dict[str, dict[str, Any]]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    return {item["id"]: item for item in data["dials"]}


def load_settings(settings_path: Path, dial_catalog: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """Load settings without silently discarding malformed or unknown values."""
    settings_path = Path(settings_path)
    if settings_path.exists():
        try:
            data = json.loads(settings_path.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError):
            # Preserve the parsing error for the caller so the file is not
            # overwritten with defaults without explicit user action.
            raise
        if not isinstance(data, dict):
            raise DialConfigError("パーソナライズ設定の最上位は JSON オブジェクトである必要があります。")
        active = data.get("active_dial_ids")
        values = data.get("values")
        if not isinstance(active, list):
            raise DialConfigError("active_dial_ids は配列で指定してください。")
        if not isinstance(values, dict):
            raise DialConfigError("values は JSON オブジェクトで指定してください。")

        valid_active: list[str] = []
        seen: set[str] = set()
        for dial_id in active:
            if not isinstance(dial_id, str) or not dial_id.strip():
                raise DialConfigError("active_dial_ids には空でない文字列の ID が必要です。")
            if dial_id not in dial_catalog:
                raise DialConfigError(f"設定に未登録のダイヤル ID があります: {dial_id}")
            if dial_id in seen:
                raise DialConfigError(f"active_dial_ids に重複があります: {dial_id}")
            seen.add(dial_id)
            valid_active.append(dial_id)

        clean_values: dict[str, int] = {}
        for dial_id, raw_value in values.items():
            if not isinstance(dial_id, str) or dial_id not in dial_catalog:
                raise DialConfigError(f"values に未登録のダイヤル ID があります: {dial_id!r}")
            if not isinstance(raw_value, int) or isinstance(raw_value, bool) or not 1 <= raw_value <= 5:
                raise DialConfigError(f"{dial_id} の値は 1〜5 の整数で指定してください。")
            clean_values[dial_id] = raw_value
        for dial_id in valid_active:
            clean_values.setdefault(dial_id, 3)
        return {
            "schema_version": str(data.get("schema_version", "0.1")),
            "active_dial_ids": valid_active,
            "values": clean_values,
        }

    initial_ids = [
        dial_id for dial_id, spec in dial_catalog.items()
        if spec.get("stage") == "initial"
    ]
    return {
        "schema_version": "0.1",
        "active_dial_ids": initial_ids,
        "values": {dial_id: 3 for dial_id in initial_ids},
    }



def select_visible_dials(
    dial_catalog: dict[str, dict[str, Any]],
    settings: dict[str, Any],
    *,
    include_advanced: bool = False,
) -> dict[str, dict[str, Any]]:
    """Return basic dials plus already-active dials; reveal all only on request."""
    active = set(settings.get("active_dial_ids", []))
    return {
        dial_id: spec
        for dial_id, spec in dial_catalog.items()
        if spec.get("stage") == "initial" or dial_id in active or include_advanced
    }

def save_settings(settings_path: Path, settings: dict[str, Any]) -> None:
    settings_path = Path(settings_path)
    settings_path.parent.mkdir(parents=True, exist_ok=True)
    settings_path.write_text(
        json.dumps(settings, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def update_dial(
    settings: dict[str, Any],
    dial_catalog: dict[str, dict[str, Any]],
    dial_id: str,
    value: int,
) -> dict[str, Any]:
    """Activate a dial and update its value, leaving other settings intact."""
    if dial_id not in dial_catalog:
        raise DialConfigError(f"未登録のダイヤル ID です: {dial_id}")
    if not isinstance(value, int) or isinstance(value, bool) or not 1 <= value <= 5:
        raise DialConfigError("ダイヤル値は 1〜5 の整数で指定してください。")

    active = list(settings.get("active_dial_ids", []))
    if dial_id not in active:
        active.append(dial_id)
    values = dict(settings.get("values", {}))
    values[dial_id] = value
    return {
        "schema_version": "0.1",
        "active_dial_ids": active,
        "values": values,
    }


def complexity_advice(settings: dict[str, Any], threshold: int = 10) -> str | None:
    """Return a proposal when the number of active independent dials hits threshold."""
    count = len(set(settings.get("active_dial_ids", [])))
    if count >= threshold:
        return (
            f"有効な独立ダイヤルが {count} 個です（提案閾値：{threshold} 個）。\n"
            "関連するダイヤルのグループ化や重複整理を提案します。\n"
            "設定は自動変更しません。必要な場合だけ利用者が選択してください。"
        )
    return None


_DIAL_DIRECTIVES = {
    "D-001": [
        "Use the shortest answer that still answers the request.",
        "Keep the answer concise and omit nonessential detail.",
        "Use balanced detail for the task.",
        "Explain relevant context and steps in detail.",
        "Provide thorough detail, edge cases, and useful context without padding.",
    ],
    "D-002": [
        "Prefer natural prose unless structure is needed.",
        "Use light structure and only a few labels.",
        "Use a balanced mix of prose and structure.",
        "Organize complex material with headings, lists, or tables.",
        "Make the information architecture explicit with sections and categorized items.",
    ],
    "D-003": [
        "Run only the checks essential for a low-impact answer; never claim checks not performed.",
        "Check the most material assumptions and claims.",
        "Check important assumptions, claims, and acceptance conditions.",
        "Systematically check claims, assumptions, edge cases, and acceptance criteria.",
        "Use comprehensive validation where feasible and state remaining verification limits.",
    ],
    "D-004": [
        "Avoid unnecessary criticism when the approach is adequate.",
        "Mention only obvious weaknesses.",
        "Check the main limitations and alternatives.",
        "Actively examine weaknesses, counterexamples, and trade-offs.",
        "Stress-test the approach with alternatives and failure cases while remaining constructive.",
    ],
    "D-005": [
        "Do not add suggestions unless asked or clearly necessary.",
        "Offer a next step only when it materially helps.",
        "Offer a small number of useful next steps when appropriate.",
        "Proactively identify improvements and practical next actions.",
        "Actively surface high-value alternatives and next actions, distinguishing proposals from decisions.",
    ],
    "D-006": [
        "Mention uncertainty only when it changes the decision or conclusion.",
        "Briefly flag important uncertainty.",
        "Separate established points from material estimates and unknowns.",
        "Explicitly label facts, inferences, assumptions, and unknowns.",
        "Make uncertainty and confidence boundaries highly visible; do not imply certainty without evidence.",
    ],
    "D-007": [
        "Prefer plain language and explain unavoidable technical terms.",
        "Use few technical terms and define them when useful.",
        "Balance accessible language with relevant terminology.",
        "Use technical terms when they improve precision.",
        "Use precise specialist terminology where useful, without using jargon as decoration.",
    ],
    "D-008": [
        "Ask when a material blocker prevents a safe or useful answer; otherwise state a reversible assumption.",
        "Prefer assumptions for low-impact unknowns; ask for material blockers.",
        "Ask when the answer would materially change the result.",
        "Ask about significant ambiguity before committing to a consequential path.",
        "Prefer clarification for material ambiguity, but do not repeat questions already answered in context.",
    ],
    "D-009": [
        "Separate facts from guesses only when it materially matters.",
        "Label obvious assumptions.",
        "Distinguish facts, assumptions, and hypotheses when relevant.",
        "Explicitly label fact, inference, hypothesis, and unknown.",
        "Track provenance and confidence for material claims wherever possible.",
    ],
    "D-010": [
        "Do not add a counterargument section unless needed.",
        "Mention one obvious alternative when relevant.",
        "Consider the main alternative explanation.",
        "Compare the main view with plausible counterarguments.",
        "Systematically consider competing explanations and explain why they are stronger or weaker.",
    ],
    "D-011": [
        "Check only for direct contradictions.",
        "Check obvious conflicts in requirements and output.",
        "Check relevant conflicts between assumptions, constraints, and conclusions.",
        "Run a structured consistency check across requirements and outputs.",
        "Explicitly track conflicting requirements, version mismatches, and unresolved inconsistencies.",
    ],
    "D-012": [
        "Use only immediately relevant context.",
        "Carry forward essential state only.",
        "Retain the active goal, decisions, and open issues.",
        "Maintain a compact working state with decisions and unresolved items.",
        "Preserve relevant project state and decision history, while excluding unrelated or sensitive context.",
    ],
    "D-013": [
        "Avoid retries unless there is a clear reason.",
        "Try an alternative only when the first route has a specific failure.",
        "Consider one useful alternative when it is permitted and worthwhile.",
        "Proactively consider registered alternative routes after a meaningful failure.",
        "Explore useful registered alternatives up to the configured retry budget; never bypass policy or approval.",
    ],
}


def build_dial_overlay(
    settings: dict[str, Any],
    dial_catalog: dict[str, dict[str, Any]],
) -> dict[str, Any]:
    """Compile numeric dials into a provider-neutral preference overlay.

    The output is a set of intended behavior directives, not a direct control over
    model internals. Provider adapters may translate the directives to their own
    prompt format, while preserving the non-overridable invariants.
    """
    active = settings.get("active_dial_ids", [])
    values = settings.get("values", {})
    if not isinstance(active, list) or not isinstance(values, dict):
        raise DialConfigError("ダイヤル設定の active_dial_ids / values が不正です。")

    preferences: list[dict[str, Any]] = []
    seen: set[str] = set()
    for dial_id in active:
        if not isinstance(dial_id, str) or dial_id not in dial_catalog:
            raise DialConfigError(f"未登録の有効ダイヤル ID です: {dial_id!r}")
        if dial_id in seen:
            continue
        seen.add(dial_id)
        raw_value = values.get(dial_id, 3)
        if not isinstance(raw_value, int) or isinstance(raw_value, bool) or not 1 <= raw_value <= 5:
            raise DialConfigError(f"{dial_id} の値は 1〜5 の整数で指定してください。")
        directive_table = _DIAL_DIRECTIVES.get(dial_id)
        if directive_table is None:
            # Future dials must ship an explicit translation instead of silently
            # behaving like a known dial with a similar name.
            raise DialConfigError(f"{dial_id} に provider-neutral directive が定義されていません。")
        if not isinstance(directive_table, list) or len(directive_table) != 5:
            raise DialConfigError(f"{dial_id} の directive は値1〜5に対応する5段階で定義してください。")
        preferences.append({
            "dial_id": dial_id,
            "name": dial_catalog[dial_id].get("name", dial_id),
            "value": raw_value,
            "directive": directive_table[raw_value - 1],
        })

    return {
        "schema_version": "0.3",
        "overlay_type": "personalization_dials",
        "scope": ["response_style", "interaction_preferences", "bounded_recovery_preferences"],
        "preferences": preferences,
        "non_overridable_invariants": [
            "Do not weaken safety, legal, privacy, or platform constraints.",
            "Do not grant execution permissions or invent capabilities.",
            "Do not claim execution or verification that did not occur.",
            "Do not bypass human approval requirements.",
            "Keep retries within the runtime's explicit retry budget.",
            "Treat current-task instructions as session-scoped unless the user explicitly changes stable settings.",
        ],
    }


def build_personalization_overlay(
    settings: dict[str, Any],
    dial_catalog: dict[str, dict[str, Any]],
    persona_seed: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Assemble a portable, model-neutral Persona Seed + Dial overlay.

    Only known Seed sections are copied. Provider-specific prompt compilation is
    intentionally left to adapters, and fixed policy invariants remain outside
    the user's configurable Seed and Dials.
    """
    dial_overlay = build_dial_overlay(settings, dial_catalog)
    normalized_seed: dict[str, Any] | None = None
    if persona_seed is not None:
        if not isinstance(persona_seed, dict):
            raise DialConfigError("Persona Seed は JSON オブジェクトで指定してください。")
        schema = persona_seed.get("schema")
        seed_id = persona_seed.get("seed_id")
        version = persona_seed.get("version")
        if not isinstance(schema, str) or not schema.startswith("persona-seed/"):
            raise DialConfigError("Persona Seed の schema は persona-seed/ で始まる必要があります。")
        if not isinstance(seed_id, str) or not seed_id.strip():
            raise DialConfigError("Persona Seed に seed_id が必要です。")
        if not isinstance(version, str) or not version.strip():
            raise DialConfigError("Persona Seed に version が必要です。")

        section_names = (
            "communication_style",
            "reasoning_preferences",
            "interaction_policy",
            "output_preferences",
        )
        normalized_seed = {
            "schema": schema,
            "seed_id": seed_id.strip(),
            "version": version.strip(),
        }
        purpose = persona_seed.get("purpose")
        if purpose is not None:
            if not isinstance(purpose, str):
                raise DialConfigError("Persona Seed の purpose は文字列で指定してください。")
            normalized_seed["purpose"] = purpose.strip()
        for section_name in section_names:
            section = persona_seed.get(section_name, {})
            if not isinstance(section, dict):
                raise DialConfigError(f"Persona Seed の {section_name} は JSON オブジェクトで指定してください。")
            normalized_seed[section_name] = dict(section)

        scope = persona_seed.get("scope", {})
        if not isinstance(scope, dict):
            raise DialConfigError("Persona Seed の scope は JSON オブジェクトで指定してください。")
        normalized_scope: dict[str, list[str]] = {}
        for field in ("may_influence", "must_not_override"):
            items = scope.get(field, [])
            if not isinstance(items, list) or any(not isinstance(item, str) or not item.strip() for item in items):
                raise DialConfigError(f"Persona Seed の scope.{field} は文字列配列で指定してください。")
            normalized_scope[field] = list(dict.fromkeys(item.strip() for item in items))
        normalized_seed["scope"] = normalized_scope

    return {
        "schema_version": "0.3",
        "overlay_type": "personalization",
        "persona_seed": normalized_seed,
        "dials": dial_overlay["preferences"],
        "precedence": [
            "safety_legal_platform_and_actual_permissions",
            "explicit_current_task_requirements",
            "project_and_task_contracts",
            "session_scoped_overrides",
            "persona_seed_and_dials",
            "provider_defaults",
        ],
        "non_overridable_invariants": dial_overlay["non_overridable_invariants"],
        "notes": [
            "This overlay expresses preferences; it does not change model internals.",
            "Provider adapters must compile these fields into provider-specific instructions.",
            "Persona Seed and Dials cannot create capabilities, facts, permissions, or verification evidence.",
        ],
    }
