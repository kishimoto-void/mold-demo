# DEMO-002 — 既存 MD の起動

- **Status:** Draft / CLI demo
- **Target molds:** MOLD-003, MOLD-005
- **Preconditions:** 読み込み可能な非空の MD が存在する状態
- **Execution environment:** Python CLI on PC or Android Python environment; no LLM app or external service is automatically controlled by this demo.

## Steps
1. MD を読み込んで PRESENT と判定する
2. 既存ファイルを保持する
3. 現在のダイヤルを表示し、必要に応じて再調整を案内する

## Expected result
既存 MD が認識され、利用者の明示なしに上書きされない。

## Verification status
Python のデモ骨格は含まれる。LLM / 外部サービスとの実運用は、別途アダプターの実装と確認が必要。
