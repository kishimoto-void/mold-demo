# DEMO-001 — MD なしからの起動

- **Status:** Draft / CLI demo
- **Target molds:** MOLD-003, MOLD-004, MOLD-008
- **Preconditions:** config/persona.md が存在しない状態
- **Execution environment:** Python CLI on PC or Android Python environment; no LLM app or external service is automatically controlled by this demo.

## Steps
1. 起動時に MD の状態を確認する
2. ABSENT を判定し、案内付き設定 / 標準設定 / 終了を提示する
3. 初期ダイヤル 8 個を表示する

## Expected result
MD がないことだけで異常終了せず、設定作成は明示的な選択後だけ行う。

## Verification status
Python のデモ骨格は含まれる。LLM / 外部サービスとの実運用は、別途アダプターの実装と確認が必要。
