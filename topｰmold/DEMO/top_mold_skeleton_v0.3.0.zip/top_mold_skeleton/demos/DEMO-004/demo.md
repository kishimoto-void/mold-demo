# DEMO-004 — 10 個以上の拡張提案

- **Status:** Draft / CLI demo
- **Target molds:** MOLD-006, MOLD-007
- **Preconditions:** 初期 8 個に追加ダイヤル 2 個を加え、有効ダイヤルが 10 個に達した状態
- **Execution environment:** Python CLI on PC or Android Python environment; no LLM app or external service is automatically controlled by this demo.

## Steps
1. 有効な独立ダイヤル数を数える
2. 閾値 10 と比較する
3. 整理・グループ化を提案するが、自動変更はしない

## Expected result
10 個以上の場合に提案し、利用者の許可なく統合・削除しない。

## Verification status
Python のデモ骨格は含まれる。LLM / 外部サービスとの実運用は、別途アダプターの実装と確認が必要。
