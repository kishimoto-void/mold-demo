# Demo Catalog

| Demo ID | Purpose | Command |
|---|---|---|
| DEMO-001 | MD なしからの起動 | `python main.py --demo DEMO-001` |
| DEMO-002 | 既存 MD の起動 | `python main.py --demo DEMO-002` |
| DEMO-003 | ダイヤルの再調整 | `python main.py --demo DEMO-003` |
| DEMO-004 | 10 個以上の拡張提案 | `python main.py --demo DEMO-004` |
| DEMO-005 | 汎用能力ルート計画 | `python main.py --demo DEMO-005` |

各デモの詳細は対応するディレクトリの `demo.md` を参照する。
