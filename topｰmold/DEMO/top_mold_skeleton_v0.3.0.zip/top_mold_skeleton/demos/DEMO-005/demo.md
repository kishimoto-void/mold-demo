# DEMO-005 — Provider-Neutral Capability Route Planning

- **Status:** ローカルで確認できる計画生成デモ
- **Input:** `config/task.example.json`, `config/processor_registry.json`
- **Command:** `python main.py --demo DEMO-005`
- **Expected:** 能力の順序、入力型、候補の優先順位を使い、同じ入力から同じルートを作る。
- **Boundary:** 計画生成のみ。LLM / API / 外部ツール / 登録プロセッサの実行はしない。
- **Test:** `tests/test_planner.py`
