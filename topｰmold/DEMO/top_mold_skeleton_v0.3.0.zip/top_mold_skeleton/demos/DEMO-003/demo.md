# DEMO-003 — ダイヤルの再調整

- **Status:** Draft / CLI demo
- **Target molds:** MOLD-005, MOLD-006
- **Preconditions:** 初期ダイヤルが設定済みで、利用者が調整を希望した状態
- **Execution environment:** Python CLI on PC or Android Python environment; no LLM app or external service is automatically controlled by this demo.

## Steps
1. 現在値を表示する
2. 利用者が変更対象 ID と値 1〜5 を指定する
3. 変更対象だけを更新し、他の設定値を維持する

## Expected result
設定の差分が明確で、非対象の値は更新されない。

## Verification status
Python のデモ骨格は含まれる。LLM / 外部サービスとの実運用は、別途アダプターの実装と確認が必要。
