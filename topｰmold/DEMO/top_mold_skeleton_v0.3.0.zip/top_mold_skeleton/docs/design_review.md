# Design Review — Top Mold v0.3

## Executive decision

Keep the Top Mold core small and stable. Move from a "top prompt that contains everything" to a **contract-driven control kernel** that can host different request compilers, middle molds, reasoning circuits, bottom LLMs, and tools.

## What should be in the top mold

- Request / task / result / adapter contracts.
- Policy boundaries, approval states, and explicit failure modes.
- Component registries and a deterministic route planner.
- A consistent lifecycle for request normalization, planning, execution, validation, and result reporting.
- Persona Seed / Capsule / Dial interfaces, without binding the kernel to one person's full profile.
- A trace contract that records versions, selected route, outcomes, and the actual verification environment.

## What should remain replaceable

- Semantic interpretation of free text.
- Domain-specific reasoning circuits, specialist prompts and knowledge packs.
- Provider-specific instructions, API calls, auth and rate limits.
- Visual UI and device-specific integration.
- Domain result evaluators and research methods.

## Refinement from different angles

### 1. Generality

Use capability labels and schemas instead of hard-coded provider names or domain names. “Can verify a claim” is a capability; “use model X” is a provider binding. Keep the latter in a registry or adapter.

### 2. Fidelity to the user

Store the original request separately from its normalized interpretation. Keep inferred requirements labeled as inferred. That makes design improvement possible without quietly rewriting intent.

### 3. Modularity

Require stable contracts at module boundaries. Top, middle, and bottom may be developed independently as long as they implement the same contract and pass conformance tests.

### 4. Operational truthfulness

A valid route is not an execution. An execution is not proof of correctness. A plausible answer is not verification. Separate the states and attach evidence wherever the next state is claimed.

### 5. Personalization UX

The initial dial screen is useful for making the user aware of controllable preferences, but reopening it every launch creates friction. Show the basic dials during initial setup and only reopen the editor on request. Put advanced controls behind an explicit configuration step.

### 6. Cognitive / interaction load

Do not ask about every unknown. Ask only when an answer changes the plan materially. For low-impact choices, proceed with a reversible assumption and name it. Preserve a blocking-question status for safety, high-impact, or irreversible decisions.

### 7. Complexity management

A general-purpose shell can become a pile of meta-features. Add a component only when it has a stable interface, a distinct responsibility, and a testable acceptance criterion. The 10-dial threshold is a review trigger, not a growth target.

### 8. Platform realism

Keep the core Python small and standard-library-only. Do not say Android or PC is supported until the corresponding environment has been exercised. The user's device and the development/test environment are separate facts.

### 9. Failure and recovery

Classify missing provider, type mismatch, forbidden mode, missing output, blocked intake, timeout, and invalid result separately. Define a retry budget and policy in a future execution layer; never let “be proactive” become endless retries.

### 10. Growth path

First stabilize contracts and plan-only tests; then implement trace and result validation; next add manual/local adapters; only then integrate external LLM APIs one at a time. This avoids coupling the architecture to one provider before the common contract is proven.

## Deliberate non-goals for v0.3

- No autonomous, unconstrained agent loop.
- No claim to control hidden LLM state or weights.
- No universal semantic parser embedded in pure Python.
- No auto-merging of persona settings or dials.
- No API credentials, network calls, or device automation.

## Acceptance criteria

- A structured request packet is validated before planning.
- Non-READY packets cannot be planned as executable tasks.
- The plan is deterministic for the same task and registry.
- A missing/invalid personalization file never silently overwrites the user's file.
- Dial configuration is not repeated every normal launch.
- Existing and new tests pass without third-party packages.
