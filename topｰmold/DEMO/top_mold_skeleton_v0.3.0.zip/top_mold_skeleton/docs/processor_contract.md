# Processor Descriptor — v0.3

`config/processor_registry.json` は能力を提供する候補の一覧。MOLD ID の責任定義とは別の登録領域で、プロバイダー名や個別モデル名を ID に含めない。

| フィールド | 意味 |
|---|---|
| `id` | `PROC-XXX` 形式の候補 ID |
| `capabilities` | 提供できると宣言された能力ラベル |
| `accepts` | 候補が受け取れる入力型。空配列は型制約なし |
| `produces` | 候補が生成する出力型ラベル |
| `execution_mode` | `local`, `llm_adapter`, `external_tool`, `manual` などの実行方式ラベル |
| `status` | `planning_only`, `ready`, `disabled` |
| `priority` | 候補の選択優先度。大きいほど優先 |
| `adapter_id` | 接続するアダプター ID。未接続なら `null` |
| `entrypoint` | 実行境界のエントリポイント参照。未実装なら `null` |

## ステータスの意味

- `planning_only`: 設計・選択の対象にはなるが、実行可能とは宣言していない。
- `ready`: 実行側が検証済みエントリポイントを登録した状態。トップモールドの現行コードはエントリポイントを呼び出さない。
- `disabled`: ルーティング候補から除外。

サンプルの全候補は `planning_only`。ルートが `COMPLETE` になっても、実行可能性が検証済みという意味ではない。
