# Task Envelope — v0.3

The Task Envelope is the planner-ready representation of a task. A structured Intake Packet may be the source, or a developer / human may supply the Task Envelope directly.

| Field | Meaning |
|---|---|
| `task_id` | Stable identifier |
| `goal` | Intended outcome |
| `input_types` | Input type labels available at the start |
| `required_capabilities` | Ordered sequence of capabilities to route through |
| `output_contract` | Required final output type labels |
| `constraints.forbidden_execution_modes` | Execution modes that must not be used |
| `constraints.require_verification` | Whether verification is mandatory |
| `constraints.human_approval_required` | Whether explicit human approval is mandatory |
| `risk_level` | `low`, `normal`, `high`, or `critical` |
| `context_refs` | Opaque references to relevant context; planner does not fetch their content |

## Contract boundaries

- `required_capabilities` is a desired capability sequence, not a list of providers. The planner does not silently reorder it.
- `input_types`, `accepts`, and `produces` are compatibility labels, not the actual payload.
- Constraints that cannot be met remain visible in the plan output.
- A `COMPLETE` plan means the declared route matches the planning contract. It does not mean a processor ran or the answer was correct.
- Free-text interpretation lives in an upstream, replaceable Intent Compiler; `core/planner.py` does not infer capabilities from the goal string.
