# Top Mold v0.3 — Control Plane

## 目的

要求・制約・能力・実行状態を一貫した契約でつなぎ、個別LLMや専門領域を交換してもトップ層を書き換えずに済むこと。

## 制御フロー

```text
INPUT
 ↓ Raw Request (原文を保持)
Intent Compiler (交換可能)
 ↓ Intake Packet
Intake Validator
 ↓ Task Envelope
Policy / Permission Boundary
 ↓ Route Planner ← Registries
Execution Adapter (not implemented)
 ↓ Result Envelope (contract proposed)
Validation / Reconciliation (future)
 ↓ Output + Trace
```

## 制御の基本責任

1. 原文・正規化目的・原子的要件を分けて保持する。
2. 明示された要件と推定した要件を混同しない。
3. 制約・承認・禁止実行方式をPersona設定から分離する。
4. 能力宣言・入出力型・実行方式に基づいてルートを選ぶ。
5. 計画・実行・検証の各状態を明示する。
6. 未解決事項、失敗理由、仮定、採用ルート、環境を追跡可能にする。

## 設定の優先関係

1. 安全・法令・プラットフォーム制約、実際の実行権限。
2. 現在の要求に明示された必須条件と明示的な確認・承認。
3. プロジェクト契約・タスク契約・実行ポリシー。
4. 現セッションのみの上書き指定。
5. Persona Seed / Persona Capsule / Dials。
6. モデルやアダプターの既定値。

上位レベルと下位レベルが競合した場合、黙って下位を優先せず、適用したルールまたは衝突を記録する。current request がプロジェクト要件を意図的に改訂する場合は、仕様変更として扱い、既存の契約を無言で書き換えない。

## ルート選択規則

- 能力順序は Intake / Task Envelope に明示された配列順。
- 能力候補は `capabilities`、`accepts`、`execution_mode`、`status`、出力型で適合判定する。
- 禁止モードの候補は採用しない。
- 出力契約までつながる全体経路を優先する。
- 能力不足や制約未達は `PARTIAL` と理由で返す。
- Plan-only prototype では `execution_invoked=false` を保つ。

## トップが勝手にやらないこと

- 足りない要求・事実・能力を創作して埋める。
- Persona から実行権限を推定する。
- 未実行の処理や未検証の能力を完了と報告する。
- 利用者の既存ファイルを確認なく上書きする。
- 無制限な retry / alternate-route を実行する。
