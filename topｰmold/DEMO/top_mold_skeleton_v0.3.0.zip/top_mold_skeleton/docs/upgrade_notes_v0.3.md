# Upgrade Notes — v0.2 to v0.3

## Preserved

- Original MOLD registry and the original startup / persona MD state checks.
- The eight basic and five advanced dials, including the 10-dial complexity proposal rule.
- Provider-neutral Task Envelope and deterministic capability route planning.
- Explicit distinction between a plan and actual execution.

## Added

- `core/intake.py`: validates the request decomposition packet and maps only `READY` packets to a Task Envelope.
- `config/intake.example.json`: a structured request example with atomic requirements, assumptions, questions, acceptance criteria, routing, and decision status.
- `config/persona_seed.example.json`: portable Persona Seed interface example.
- `build_dial_overlay` / `build_personalization_overlay`: compile dial values and an optional Persona Seed into a model-neutral preference overlay; provider-specific prompt compilation remains unimplemented.
- `--intake` CLI route to validate a request packet and plan when READY.
- `--configure` / `--advanced-dials` switches; normal startup reports only the active dial count, and the full list appears only on first setup or explicit configuration.
- Design review, responsibility matrix, Persona Seed boundary, and trace/reproducibility documents.

## Compatibility notes

`--task`, `--demo`, current `config/dials.json`, existing `config/personalization.example.json`, and `config/mold_registry.json` remain supported. Existing Task Envelope JSON stays valid under the planner.

## Still not implemented

The intake module validates structured output; it does not parse raw Japanese/English text by itself. No LLM adapter or external execution was added. Persona Seed is an example contract and is not automatically compiled into provider prompts.
