# Trace and Reproducibility Contract — Proposed

A useful result should make it possible to answer: what request and settings produced it, what route was selected, what actually ran, what failed, and in which environment the claim was verified?

## Trace fields

- `trace_id`, `task_id`, `request_id`
- request packet schema version, top mold version, mold/processor/adapter versions
- Persona Seed version or safe reference, active dial IDs/values, session overrides (avoid logging irrelevant or sensitive content)
- registry fingerprint / hash and selected route with reason for each step
- planned status and actual execution status as separate fields
- result status, evidence refs, assumptions, unresolved items, error category, retry count
- `environment.device`: `smartphone` / `pc` / `server` / `unknown`
- OS / runtime / app or API / model identifier when directly known and relevant
- `verified_by`, verification date, and scope of validation

## Rules

1. Do not claim an actual device, model version, or adapter was used unless it was measured or supplied by the runner.
2. Unknown values stay `unknown` or `null`; do not infer them from an unrelated machine or from chat context.
3. Hashes identify exact serialized artifacts only when canonicalization rules are specified. A digest is not proof that the content is correct.
4. Do not put credentials, access tokens, secrets, or unnecessary personal data in traces.
5. Separate `planned`, `invoked`, `succeeded`, `verified`, and `accepted` states.
6. Environment claims are scoped: passing desktop tests does not establish Android behavior.

This file defines a proposed contract; full trace persistence and hardware verification are not implemented in this version.
