# Upgrade Notes — v0.1 to v0.2

See `docs/upgrade_notes_v0.3.md` for the latest evolution. Version 0.2 introduced the provider-neutral Task Envelope, processor registry, input type matching, forbidden execution mode checks, deterministic route planning, and the distinction between Persona overlay and routing core.
