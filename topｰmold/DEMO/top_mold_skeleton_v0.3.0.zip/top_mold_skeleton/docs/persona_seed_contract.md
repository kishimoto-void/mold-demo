# Persona Seed / Capsule / Dials — Contract and Boundaries

## Three separate concepts

### Persona Seed
Portable, relatively stable user-facing preferences and collaboration style. Example fields are provided in `config/persona_seed.example.json`. For local use, copy and edit it as `config/persona_seed.json` (the actual user profile should remain outside version control). The schema should evolve independently of the top planner.

### Persona Capsule
A bounded package compiled for a specific task or agent. It may include selected Seed fields, task-specific response style, and relevant constraints, but should not blindly copy every memory or unrelated preference.

### Dials
Small user-adjustable values that map to human-readable response or interaction policies. They do not adjust hidden model weights or guarantee identical behavior across providers.

## Separate from Session Override and Policy

- A current-task instruction applies to the current task and should not silently mutate the stable Seed.
- A stable Seed guides defaults; it cannot override safety, execution permissions, explicit hard constraints, or capability limits.
- Policy/permission checks are not a dial. No value on `D-013` may enable unlimited retry, and no value on `D-003` may claim verification happened if it did not.
- Memory/context references are selected for relevance rather than copied wholesale into every call.

## Dial interaction lifecycle

1. First setup: show the eight basic dials, with default value 3; the user can adjust or keep defaults.
2. Later normal launch: load and show a compact summary, but do not repeatedly interrupt with the adjustment dialog.
3. User asks to adjust, or CLI uses `--configure`: show the dial catalog and allow individual changes.
4. Additional dials stay optional/advanced.
5. At 10 or more active dials, suggest grouping or removing redundancy; do not auto-merge or delete.
6. Persist only explicit choices. An empty or unreadable file must not be silently overwritten.

## Current basic dials

`D-001` response detail, `D-002` structure, `D-003` verification care, `D-004` critical examination, `D-005` proactivity of suggestions, `D-006` uncertainty disclosure, `D-007` amount of jargon, `D-008` clarification frequency.

## Current advanced dials

`D-009` fact/hypothesis separation, `D-010` counterargument review, `D-011` contradiction check, `D-012` context continuity, `D-013` retry proactivity.

Retry is always bounded by a fixed system budget and policy. A high value changes preference within that budget; it does not remove the budget.
