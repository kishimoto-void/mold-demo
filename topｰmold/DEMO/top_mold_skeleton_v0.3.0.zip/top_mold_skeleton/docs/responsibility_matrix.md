# Responsibility Matrix — What belongs in Top Mold?

| Area | Top Mold core | Optional overlay / plugin | Keep outside the core |
|---|---|---|---|
| Raw request & task contract | Contract, source preservation, validation | Intent Compiler can be LLM/local/human | Domain-specific interpretation heuristics |
| Request decomposition | Required packet shape, validation, blocker status | Decomposition circuit / template | Hard-coded domain logic |
| Policy | Policy interface, constraint checks, state and approval boundary | Domain policy packs | Credentials, secrets, infrastructure enforcement |
| Registry & routing | Common schemas, deterministic plan | Extra routers and selectors | Vendor-specific API arguments |
| Persona | Seed interface and precedence | Persona Seed / Capsule profiles | Treating persona as executable authority |
| Dials | Values, UI lifecycle, bounded translation to instructions | Advanced dials or presets | Direct control of model internals |
| Execution | Adapter contract and execution status | LLM, local function, tool adapter | Actual provider runtime in a supposedly neutral core |
| Result | Result schema, validation boundary | Domain-specific evaluators | Claims of success without evidence |
| State & trace | Common metadata contract | Storage backends | Assuming the platform exposes unavailable telemetry |
| Environment | Required fields and validation | Device-specific helper | Guessing phone/PC, model version, or OS |
| Retry / recovery | Bounded policy, error categories, retry budget | Strategy plugin | Infinite retry or uncontrolled fallback |

## Decision heuristic

Put a function into Top Mold when many unrelated projects need the same stable contract and its correctness can be checked. Put it in a plugin when it depends on the model, domain, user, service, or runtime. Keep it out entirely when it claims control or evidence the system cannot actually provide.
