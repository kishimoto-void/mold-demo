# Mold Contract — Common Specification

## 必須項目

各モールドの `mold.md` は次の情報を持つ。

```yaml
mold_id: MOLD-XXX
name: Example Mold
version: 0.1.0
status: draft
purpose: One-sentence responsibility
input_contract:
  - required fields and types
output_contract:
  - expected fields and types
dependencies: []
constraints: []
failure_conditions: []
runtime_requirements:
  device: smartphone_or_pc
  external_services: []
compatibility:
  llm: provider-neutral
  mold_contract_version: 0.3
```

YAML は仕様の記入例であり、現段階の Python がこの front matter を解析するわけではない。

## v0.3 補足

共通の MOLD 契約は特定 LLM に依存しない。個別 LLM や外部ツールの入出力方式はアダプター契約で定義し、プロバイダー名をモールドの必須属性にしない。

## ID の規則

- `MOLD-XXX`：再利用可能な機能単位
- `DEMO-XXX`：決められた操作を見せる実行例
- `TEST-XXX`：期待結果を機械的に検証するテスト
- `PROC-XXX`：能力・入出力型・実行状態を宣言するプロセッサ候補
- `TASK-XXX`：目的・制約・必要能力順序・出力条件を宣言するタスク契約
- `D-XXX`：パーソナライズ・ダイヤル
- ID は一度公開したら安易に使い回さない。
- 表示名の変更と ID の変更は別に扱う。

## デモの必須項目

- デモ ID
- 対象モールド ID
- 前提条件
- 操作ステップ
- 期待結果
- 実行環境（スマートフォン / PC / 外部サービス）
- 実施済みか、未検証か

## テストの必須項目

- テスト ID
- 検証対象
- 入力条件
- 期待結果
- 合否判定
- 実行環境と実行日

## 失敗情報

成功値だけでなく、失敗理由・不足情報・未解決事項を出力契約に含められるようにする。
