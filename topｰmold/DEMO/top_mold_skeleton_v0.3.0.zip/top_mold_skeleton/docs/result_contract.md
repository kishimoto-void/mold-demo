# Result Envelope — Proposed Contract v0.3

これは次の実装段階に向けた契約案。現行コードはまだ結果の実行・統合を行わない。

```json
{
  "schema_version": "0.3",
  "task_id": "TASK-EXAMPLE",
  "step_id": "STEP-001",
  "status": "success | partial | failed | skipped | not_invoked",
  "output_types": ["candidate_result"],
  "payload_ref": "opaque-reference-or-inline-value",
  "evidence_refs": [],
  "assumptions": [],
  "unresolved_items": [],
  "error": null,
  "verification": {
    "status": "not_checked | passed | failed | partial",
    "evidence_refs": []
  },
  "runtime": {
    "device": "smartphone | pc | server | unknown",
    "os": null,
    "adapter_id": null,
    "adapter_version": null,
    "model_id": null,
    "processor_version": "0.3.0"
  }
}
```

- 成功 / 部分成功 / 失敗 / スキップ / 未実行を別状態にする。
- 実行状態と検証状態を分ける。結果が存在することは、正しいことの証明ではない。
- データの中身そのものと、メタデータ上の型ラベルを混同しない。
- 再試行や代替経路は、失敗理由と上限を記録してから上位方針に従って選ぶ。
- 出典・仮定・未解決事項を出力から落とさない。
