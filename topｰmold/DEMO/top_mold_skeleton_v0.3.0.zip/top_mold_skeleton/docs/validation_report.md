# Validation Report — Top Mold v0.3.0-draft

## Automated checks

- Test command: `python -m unittest discover -s tests -v`
- Tested areas: personalization dial defaults/range/persistence rules, Persona file states, mold registry uniqueness, Task Envelope validation, deterministic capability routing, forbidden mode handling, output/verification constraint reporting, Intake Packet cross-field consistency, blocking-question status, atomic requirement ID uniqueness, and READY-only conversion.
- Result: 30 tests passed in the final local test run. CLI smoke checks passed for `--intake`, `--show-overlay --persona-seed config/persona_seed.example.json`, `--task`, `--help`, and the first-setup vs normal-startup interaction lifecycle in a temporary project copy.

## Environment

- Test host: Linux x86_64 container, Python 3.13.5.
- Device verification status: smartphone / Android not tested; a separate user PC environment was not tested.

## Scope and limits

Tests validate local Python contracts and planning behavior only. They do not verify external LLM APIs, ChatGPT/Gemini/Grok app behavior, authorization controls, the user's Android phone, or any PC/server environment. No LLM or external tool is invoked by the prototype.
