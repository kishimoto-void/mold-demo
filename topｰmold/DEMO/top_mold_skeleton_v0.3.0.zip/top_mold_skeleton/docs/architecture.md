# Architecture — Top Mold Universal Control Skeleton v0.3

## 1. 基本の考え方

トップモールドは万能の推論エンジンではなく、**交換可能な処理資源を契約に基づいて束ねる制御カーネル**。中核ロジックを小さく保ち、自由文の解釈、専門思考、LLM固有処理、外部ツール実行をプラグイン境界へ出す。

## 2. 主要データフロー

```text
Raw Request
  ↓
Intent Compiler (pluggable, semantic work)
  ↓ Intake Packet
Intake Validator (implemented)
  ↓ Task Envelope
Policy Gate (contract / future enforcement boundary)
  ↓
Capability Planner (implemented; plan-only)
  ↓
Adapter / Processor (contract documented, runtime not implemented)
  ↓ Result Envelope (contract proposed)
Validator / Reconciler (future)
  ↓
Output + Trace
```

Persona Seed と Dials は要求解析の表現方針や最終回答の形式を調整する横断レイヤー。ハード制約や実行権限より弱い設定である。

## 3. 責務の分割

| Component | Owns | Does not own |
|---|---|---|
| Intake / Intent Compiler | 原文の整理、要件候補、前提、質問 | 実行権限の付与、結果の捏造 |
| Intake Validator | packet schema と cross-field consistency | 自由文の意味理解 |
| Policy Boundary | 禁止事項、リスク、承認、データ境界 | Personaの好みの推定 |
| Capability Planner | 宣言能力、型、順序、出力契約の照合 | ドメイン固有の意味推論 |
| Registry | 能力と接続情報の宣言 | 実装されていない能力を実在扱いすること |
| Adapter | 共通契約をLLM/API/ツールへ翻訳 | 共通契約を書き換えること |
| Result Validator / Reconciler | 状態、根拠、矛盾、不足の評価 | 未実行処理を成功扱いにすること |
| Persona / Dials | スタイルと対話方針の調整 | 能力・権限・事実の生成 |
| Trace | バージョン、ルート、環境、結果の記録 | 未計測の環境を推測で埋めること |

## 4. Three-plane model

### Control plane
Task contracts, policy checks, component registries, deterministic routing, explicit state transitions.

### Execution plane
LLM adapters, local code, remote APIs, tools, manual handoff. This is separate and not implemented by the current prototype.

### Cross-cutting plane
Persona Seed, Dials, temporary overrides, trace, provenance, version and environment metadata.

## 5. Top / Middle / Bottom の関係

- **Top Mold**：タスク境界、制約、契約検証、ルート案、結果状態、トレース。
- **Middle Mold / Reasoning Circuit**：ドメインや手順に応じた分解、仮説、処理順序、専門方針。複数実装を交換できる。
- **Bottom Executor**：モデル・コード・API・ツールを使って具体的な処理を行う。

Top は middle が作った capability sequence を検証・接続する。指定された順序を勝手に並び替えない。別ルートを作る場合は、契約された planner policy と registry を使い、理由を残す。

## 6. 決定論と失敗の扱い

- 候補は優先度降順、同値なら ID 昇順で比較する。
- 出力契約を満たす全体経路を、個々の高優先候補より優先する。
- 能力なし、入力型不一致、禁止モード、出力型不足、検証能力不足を区別する。
- 同じ入力と同じレジストリで同じ計画を返す。
- Plan status `COMPLETE` はルート計画が契約上接続できることを示すだけで、実行成功を示さない。

## 7. 安全性の境界

レジストリ内の `forbidden_execution_modes` は計画時に候補を除外する。実際の認証、送信先、プライバシー、実行権限、予算・レート制限を保証するには、アダプター側で強制しテストする必要がある。設定値だけで実アクセスが保護されるとは扱わない。

## 8. 次の実装順

1. Result Envelope の正規化と検証。
2. Trace Record の作成（契約、モデル、アダプター、端末、OS、結果状態）。
3. 手動ハンドオフまたは安全なローカル関数で Adapter Interface を実装。
4. 明示的な retry budget、承認点、失敗カテゴリを実装。
5. 複数結果の出典照合・差分統合。
6. API 接続は最小1系統ずつ追加し、認証・失敗・データ境界のテストを行う。
