# Request Intake Contract — v0.3

## 目的

ユーザーの自由文を、そのまま route planner に渡すのではなく、要求の意味を保った構造化パケットへ変換する。その意味解釈を特定モデルへ埋め込まず、LLM / local model / human / middle mold を差し替えられるようにする。

`core/intake.py` は自由文を理解する機能ではない。上流の Intent Compiler が作った JSON の構造・値・相互整合性を検証する。

## Packet の主要項目

| フィールド | 役割 |
|---|---|
| `raw_request` | 原文の保持。編集・短縮で失ってはいけない |
| `normalized_goal` | 達成したい最終目的を短く明示 |
| `atomic_requirements` | 1項目1要件。ID、statement、priority、origin、acceptance criterion |
| `known_constraints` | 既知の必須条件・禁止条件 |
| `assumptions` | statement、confidence、impact |
| `open_questions` | question、blocking、reason |
| `acceptance_criteria` | 完成を判定する具体条件 |
| `routing` | plannerへ渡す Task Envelope の情報 |
| `decision` | `READY` / `CLARIFICATION_REQUIRED` / `BLOCKED` と rationale |

## 原子的要件の作り方

- 1つの要件に複数の独立した動作を詰め込まない。
- `priority`: `must` / `should` / `could`。
- `origin`: `explicit` は元の依頼で明言、`inferred` は解釈上の推定。
- 推定は、根拠がない限り `must` に昇格させない。
- 要件は受入条件またはテスト可能な完了基準と対応させる。

## 確認判断

- `READY`: ブロッキング質問なし。小さな不確実性は仮定として可視化されている。
- `CLARIFICATION_REQUIRED`: 回答によって安全性、費用、成果物の構造、互換性、不可逆操作などが変わり得る質問が残る。
- `BLOCKED`: 要求が矛盾している、必須情報・権限が欠ける等で現時点では進められない。停止理由を記載する。

機械的な整合性条件：`READY` に `blocking=true` の質問を含めない。`CLARIFICATION_REQUIRED` には少なくとも1つのブロッキング質問が必要。READY 以外は Task Envelope に変換して計画を実行可能扱いにしない。

## 別角度からの洗練レビュー

構造化した要求は、下記を個別に確認する。

1. **意図忠実性**：ユーザーの目的を別の目標へ置き換えていないか。
2. **完全性**：明示要求、制約、受入条件、例外が落ちていないか。
3. **汎用性**：ベンダー名、端末、業界固有語を共通層に不必要に固定していないか。
4. **交換可能性**：モデルや思考回路を差し替えても契約が保たれるか。
5. **実行可能性**：必要な能力・権限・入出力型が存在するか。
6. **失敗回復性**：不成立の理由と再開に必要な情報を返せるか。
7. **複雑さ**：実装・保守コストに比べて価値があるか。
8. **再現性**：前提、バージョン、環境、結果が記録されるか。

これらは設計レビューの軸であり、自動的に全機能を追加するリストではない。
