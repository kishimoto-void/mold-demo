# Startup / Persona Flow — v0.3

## Startup modes

### First setup

1. Inspect Persona MD as `ABSENT / PRESENT / EMPTY / ERROR`.
2. If missing, empty, or unreadable, offer onboarding only during initial setup; do not overwrite an empty or unreadable file without explicit confirmation.
3. Show the eight basic dials with default value 3.
4. Let the user adjust or keep defaults.
5. Persist explicit dial choices to `runtime/personalization.json`.

### Normal launch

1. Load existing settings.
2. Show only a compact status (for example, the number of active dials); do not list every dial.
3. Do not reopen onboarding or dial-edit prompts on every launch.
4. If Persona is missing/empty/unreadable, show a non-blocking status note rather than repeating the same prompt.

### Explicit reconfiguration

- `python main.py --configure` opens the personalization interaction again.
- The full dial list is shown only during first setup or explicit reconfiguration. The same file preservation and explicit confirmation rules apply.
- Changing one dial must preserve all unrelated settings.

## Persona file states

| State | Meaning | Behavior |
|---|---|---|
| `ABSENT` | File does not exist | Initial setup may offer a template |
| `PRESENT` | Readable and non-empty | Preserve existing content |
| `EMPTY` | Exists but has no content | Ask before replacing with a template |
| `ERROR` | Path, encoding, or permission problem | Report the error; do not assume the file is absent |

## Relationship to the top control plane

Persona and dials guide collaboration style; they are not required to construct a Task Envelope or route plan. They do not grant execution access, declare capabilities, change explicit task constraints, or replace verification. The Persona Seed example is a portable schema only; provider prompt compilation is not implemented.
