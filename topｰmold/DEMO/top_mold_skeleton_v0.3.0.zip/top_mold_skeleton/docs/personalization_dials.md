# Personalization Dials — v0.3

## Meaning

Each dial uses a value from 1 to 5. It represents an intended response or interaction policy; it does not change model weights or guarantee the same result from every provider.

| Value | Meaning |
|---:|---|
| 1 | 控えめ |
| 2 | やや控えめ |
| 3 | 標準 |
| 4 | やや強め |
| 5 | 強め |

## Initial dials

| ID | Name | Target |
|---|---|---|
| `D-001` | 回答の詳しさ | Response detail |
| `D-002` | 構造化 | Headings, stages, categories |
| `D-003` | 検証の丁寧さ | Care given to evidence and checks |
| `D-004` | 批判的検討 | Counterexamples and weaknesses |
| `D-005` | 提案の積極性 | Suggestions and next actions |
| `D-006` | 不確実性の明示 | Fact / estimate / unknown distinction |
| `D-007` | 専門用語の量 | Technical language level |
| `D-008` | 確認・相談の頻度 | When to ask the user |

## Advanced dials

| ID | Name | Target |
|---|---|---|
| `D-009` | 事実と仮説の分離 | Claim categories |
| `D-010` | 反対意見の検討 | Alternative hypotheses / counterarguments |
| `D-011` | 矛盾チェック | Cross-config and output consistency |
| `D-012` | 文脈の引き継ぎ | Relevant context continuity |
| `D-013` | 再試行の積極性 | Willingness to try alternatives within a fixed retry budget |

## UI lifecycle

1. 初回セットアップでは基本8個を表示する。
2. 既定値は3。利用者が調整せずに標準値を選ぶこともできる。
3. 通常起動では設定を繰り返し尋ねず、現在値を確認できる状態にする。
4. ダイヤルの変更は利用者が調整を求めた時だけ行う。CLIでは `python main.py --configure` を使う。高度なダイヤルも表示する場合は `python main.py --configure --advanced-dials`。
5. 高度な項目は必要時だけ有効化し、基本画面を過度に増やさない。
6. 10個以上の独立ダイヤルはグループ化・重複整理を提案する閾値。自動削除・統合はしない。

## Boundaries

- Dials cannot create capability, facts, access, or permission.
- D-003 cannot claim validation happened unless there is a validation result.
- D-008 can tune clarification behavior but cannot suppress a material blocker.
- D-013 is bounded by system and policy retry limits. A high value is not an infinite loop.
- Session instructions affect the current task and do not silently rewrite stable Persona Seed settings.

## Persistence

Local CLI settings are stored in `runtime/personalization.json`. This is a local prototype setting, not an automatically synchronized setting for any LLM application or external service.
