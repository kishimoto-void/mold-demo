# MOLD-005 — Personalization Mold

- **Version:** 0.1.0
- **Status:** Draft / skeleton
- **Purpose:** 利用者の希望をダイヤル値と MD の設定に分けて保持し、調整時には対象値のみを更新する。

## Input contract
現在設定、変更対象、値 1〜5

## Output contract
更新済み設定と差分

## Dependencies
MOLD-006, MOLD-007

## Constraints
- 役割は本書で定義した責任範囲に限定する。
- 既存の利用者設定を明示的な選択なしに変更しない。
- 実装済み・デモ済み・未検証を区別して表示する。

## Failure conditions
未登録ダイヤル、値域外、設定形式の破損

## Runtime requirements
- Device: スマートフォンまたは PC（実施時に実機を記録）
- External services: 現段階のローカル骨格では不要。外部 LLM / ツールへ接続する場合は、個別アダプターの実装と動作確認が必要。

## Demo / Test
- Demo: 対応する `demos/DEMO-XXX/` を参照
- Test: `tests/` の適合性テストで確認する。

## Implementation status
このファイルは仕様ドラフト。責任の記述はあり、汎用的な実装・本番運用が完成したことを意味しない。
