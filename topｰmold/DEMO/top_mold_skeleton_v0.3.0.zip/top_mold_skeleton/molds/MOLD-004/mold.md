# MOLD-004 — Onboarding Mold

- **Version:** 0.1.0
- **Status:** Draft / skeleton
- **Purpose:** 利用者が初期設定を選択できるよう、案内付き設定・標準設定・終了の選択肢を提示する。

## Input contract
起動状態、利用目的、設定状況

## Output contract
利用者が選択した初期化方針

## Dependencies
MOLD-003, MOLD-008

## Constraints
- 役割は本書で定義した責任範囲に限定する。
- 既存の利用者設定を明示的な選択なしに変更しない。
- 実装済み・デモ済み・未検証を区別して表示する。

## Failure conditions
選択値が不正、MD の意図しない上書き、必須確認の欠落

## Runtime requirements
- Device: スマートフォンまたは PC（実施時に実機を記録）
- External services: 現段階のローカル骨格では不要。外部 LLM / ツールへ接続する場合は、個別アダプターの実装と動作確認が必要。

## Demo / Test
- Demo: 対応する `demos/DEMO-XXX/` を参照
- Test: `tests/` の適合性テストで確認する。

## Implementation status
このファイルは仕様ドラフト。責任の記述はあり、汎用的な実装・本番運用が完成したことを意味しない。
