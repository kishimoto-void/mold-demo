# MOLD-011 — Policy and Permission Boundary

- Version: 0.3.0
- Status: design
- Responsibility: keep hard constraints, risk, consent, execution permissions, and approval states separate from personalization.

## Required behavior

- Validate explicit task constraints before route execution.
- Treat runtime permissions as enforceable adapter/runtime requirements, not just JSON flags.
- Return an explicit blocked or approval-required state when conditions are unmet.
- Never let Persona Seed or dial values relax policy, permissions, or verification requirements.

## Implementation status

Only planner-level forbidden execution mode checks and contract fields exist. No execution permission enforcement is implemented in the current prototype.
