# MOLD-001 — Mold Registry

- **Version:** 0.1.0
- **Status:** Draft / skeleton
- **Purpose:** モールド ID、表示名、バージョン、状態、仕様書パスを登録し、選択可能な型を検索する。

## Input contract
モールド定義またはレジストリ項目

## Output contract
ID で検索可能な登録情報。重複 ID はエラーとして報告する。

## Dependencies
MOLD-000

## Constraints
- 役割は本書で定義した責任範囲に限定する。
- 既存の利用者設定を明示的な選択なしに変更しない。
- 実装済み・デモ済み・未検証を区別して表示する。

## Failure conditions
ID の重複、必須フィールド不足、仕様書が存在しない

## Runtime requirements
- Device: スマートフォンまたは PC（実施時に実機を記録）
- External services: 現段階のローカル骨格では不要。外部 LLM / ツールへ接続する場合は、個別アダプターの実装と動作確認が必要。

## Demo / Test
- Demo: 対応する `demos/DEMO-XXX/` を参照
- Test: `tests/` の適合性テストで確認する。

## Implementation status
このファイルは仕様ドラフト。責任の記述はあり、汎用的な実装・本番運用が完成したことを意味しない。
