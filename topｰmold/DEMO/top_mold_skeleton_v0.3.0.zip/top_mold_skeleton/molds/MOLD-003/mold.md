# MOLD-003 — Startup Mold

- **Version:** 0.1.0
- **Status:** Draft / skeleton
- **Purpose:** 初回起動時にパーソナライズ MD とローカル設定の状態を確認し、起動分岐を選ぶ。

## Input contract
MD パス、設定パス、起動オプション

## Output contract
ABSENT / PRESENT / EMPTY / ERROR の状態と次の案内

## Dependencies
MOLD-004, MOLD-005

## Constraints
- 役割は本書で定義した責任範囲に限定する。
- 既存の利用者設定を明示的な選択なしに変更しない。
- 実装済み・デモ済み・未検証を区別して表示する。

## Failure conditions
読み込み権限不足、文字コード不正、指定先がファイルでない

## Runtime requirements
- Device: スマートフォンまたは PC（実施時に実機を記録）
- External services: 現段階のローカル骨格では不要。外部 LLM / ツールへ接続する場合は、個別アダプターの実装と動作確認が必要。

## Demo / Test
- Demo: 対応する `demos/DEMO-XXX/` を参照
- Test: `tests/` の適合性テストで確認する。

## Implementation status
このファイルは仕様ドラフト。責任の記述はあり、汎用的な実装・本番運用が完成したことを意味しない。
