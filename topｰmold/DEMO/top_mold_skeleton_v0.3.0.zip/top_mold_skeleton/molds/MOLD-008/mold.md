# MOLD-008 — Guide Mold

- **Version:** 0.1.0
- **Status:** Draft / skeleton
- **Purpose:** 入力例、ダイヤルの意味、再調整方法、デモの使い方を状況に合わせて説明する。

## Input contract
利用者の状態、利用目的、未解決の質問

## Output contract
段階的な案内と次にできる操作

## Dependencies
MOLD-004, MOLD-005

## Constraints
- 役割は本書で定義した責任範囲に限定する。
- 既存の利用者設定を明示的な選択なしに変更しない。
- 実装済み・デモ済み・未検証を区別して表示する。

## Failure conditions
案内が現在の状態と矛盾、実装していない機能を利用可能と表示

## Runtime requirements
- Device: スマートフォンまたは PC（実施時に実機を記録）
- External services: 現段階のローカル骨格では不要。外部 LLM / ツールへ接続する場合は、個別アダプターの実装と動作確認が必要。

## Demo / Test
- Demo: 対応する `demos/DEMO-XXX/` を参照
- Test: `tests/` の適合性テストで確認する。

## Implementation status
このファイルは仕様ドラフト。責任の記述はあり、汎用的な実装・本番運用が完成したことを意味しない。
