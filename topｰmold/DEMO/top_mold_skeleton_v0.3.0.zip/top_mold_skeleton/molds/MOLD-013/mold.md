# MOLD-013 — Result Validation and Reconciliation

- Version: 0.3.0
- Status: design
- Responsibility: normalize execution results, validate the result contract, preserve evidence and unresolved conflicts, and decide whether the requested acceptance criteria are met.

## Required result states

`success`, `partial`, `failed`, `skipped`, and `not_invoked` must remain distinct. A plan that can be connected is not an executed result; an executed result is not verified merely because it is non-empty.

## Required metadata

Output types, evidence references, assumptions, unresolved items, error category, adapter/runtime information, and verification state.

## Implementation status

Contract proposal exists in `docs/result_contract.md`; result validators and multi-result reconciliation are not implemented.
