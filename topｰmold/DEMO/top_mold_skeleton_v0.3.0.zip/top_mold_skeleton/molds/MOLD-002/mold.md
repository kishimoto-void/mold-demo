# MOLD-002 — Mold Connector

- **Version:** 0.1.0
- **Status:** Draft / skeleton
- **Purpose:** モールド間の入力・出力契約を確認し、境界を越えて渡すデータを明示する。

## Input contract
送信元出力、送信先入力契約

## Output contract
適合判定、変換済み入力、または接続エラー

## Dependencies
MOLD-000, MOLD-009

## Constraints
- 役割は本書で定義した責任範囲に限定する。
- 既存の利用者設定を明示的な選択なしに変更しない。
- 実装済み・デモ済み・未検証を区別して表示する。

## Failure conditions
型の不一致、必須項目不足、循環依存、非対応バージョン

## Runtime requirements
- Device: スマートフォンまたは PC（実施時に実機を記録）
- External services: 現段階のローカル骨格では不要。外部 LLM / ツールへ接続する場合は、個別アダプターの実装と動作確認が必要。

## Demo / Test
- Demo: 対応する `demos/DEMO-XXX/` を参照
- Test: `tests/` の適合性テストで確認する。

## Implementation status
このファイルは仕様ドラフト。責任の記述はあり、汎用的な実装・本番運用が完成したことを意味しない。
