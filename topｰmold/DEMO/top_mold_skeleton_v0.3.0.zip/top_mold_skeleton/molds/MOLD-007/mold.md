# MOLD-007 — Complexity Monitor Mold

- **Version:** 0.1.0
- **Status:** Draft / skeleton
- **Purpose:** 独立した有効ダイヤルの数を確認し、10 個以上の場合にグループ化や重複整理を提案する。

## Input contract
有効ダイヤル ID、閾値

## Output contract
提案の有無と理由。設定の自動変更はしない。

## Dependencies
MOLD-006, MOLD-008

## Constraints
- 役割は本書で定義した責任範囲に限定する。
- 既存の利用者設定を明示的な選択なしに変更しない。
- 実装済み・デモ済み・未検証を区別して表示する。

## Failure conditions
有効 ID の重複や未登録、誤った閾値

## Runtime requirements
- Device: スマートフォンまたは PC（実施時に実機を記録）
- External services: 現段階のローカル骨格では不要。外部 LLM / ツールへ接続する場合は、個別アダプターの実装と動作確認が必要。

## Demo / Test
- Demo: 対応する `demos/DEMO-XXX/` を参照
- Test: `tests/` の適合性テストで確認する。

## Implementation status
このファイルは仕様ドラフト。責任の記述はあり、汎用的な実装・本番運用が完成したことを意味しない。
