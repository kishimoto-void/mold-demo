# MOLD-012 — Capability Route Planner

- Version: 0.3.0
- Status: prototype
- Responsibility: choose a deterministic compatible sequence of registered processors for an explicit capability list.

## Inputs

A validated Task Envelope and a Processor Registry.

## Guarantees

- Uses the declared capability order.
- Checks capabilities, accepted input types, forbidden execution modes, and output contract.
- Prefers a complete end-to-end route over a locally high-priority candidate that prevents downstream compatibility.
- Reports unmet capability and constraint details.
- Emits a plan only; does not invoke an adapter.

## Limitations

The sequence is supplied by the task packet or another mold. Semantic decomposition, dynamic runtime fallback, and actual invocation are not implemented.
