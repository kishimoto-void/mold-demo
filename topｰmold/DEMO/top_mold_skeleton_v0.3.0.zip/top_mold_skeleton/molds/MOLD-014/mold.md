# MOLD-014 — Trace and Reproducibility

- Version: 0.3.0
- Status: design
- Responsibility: record the contracts, versions, routes, execution state, and environment behind a claim of validation.

## Required behavior

- Record smartphone / PC / server as measured or supplied, otherwise `unknown`.
- Distinguish planned, invoked, succeeded, verified, and accepted states.
- Keep a reference or canonical digest of contract and registry versions when available.
- Exclude credentials and unnecessary sensitive data.
- Scope test evidence to the environment actually tested.

## Implementation status

Schema requirements are documented in `docs/trace_and_reproducibility.md`; persistent trace writing is not implemented.
