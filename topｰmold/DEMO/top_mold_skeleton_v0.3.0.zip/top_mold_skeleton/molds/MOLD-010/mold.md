# MOLD-010 — Request Intake Contract

- Version: 0.3.0
- Status: prototype
- Responsibility: validate a structured request packet and convert READY packets into a Task Envelope.

## Inputs

A Request Intake Packet containing the original request, normalized goal, atomic requirements, assumptions, open questions, acceptance criteria, routing contract, and decision state.

## Guarantees

- Required fields and enum values are validated.
- Duplicate atomic requirement IDs are rejected.
- `READY` cannot coexist with a blocking question.
- `CLARIFICATION_REQUIRED` requires at least one blocking question.
- Only `READY` packets are converted into Task Envelopes.

## Non-goals

This mold does not semantically parse free text, select an LLM, query an external service, or decide whether inferred requirements are factually true. Those are upstream compiler responsibilities and user-facing review concerns.
