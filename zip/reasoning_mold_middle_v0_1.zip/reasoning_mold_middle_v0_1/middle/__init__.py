"""Generic Middle Mold package."""
